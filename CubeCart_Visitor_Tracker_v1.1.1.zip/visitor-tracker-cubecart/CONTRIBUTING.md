# Contributing

Thanks for your interest in Visitor Tracker for CubeCart!

## Reporting a problem

Open an issue and include:
- CubeCart version and PHP version
- Whether SEO-friendly URLs are enabled
- What you expected and what happened (a screenshot of the dashboard or the error text helps)
- Relevant lines from your PHP error log, if any

## Pull requests

- Keep the plugin compatible with **PHP 7.4 and newer** (including 8.x) and with CubeCart 6.
- The plugin must not load anything from external servers and must not store personal data (no IP addresses, no cookies, no user agents).
- Tracking code runs on every shop page: keep it fast, wrap risky code in `try/catch` and never let it break the shop.
- Hooks must be declared in `visitor_tracker/config.xml` as well as present in `visitor_tracker/hooks/`.
- Update `CHANGELOG.md` and both README files when behaviour changes.
- Test on a copy of a shop, not on a live one.

By contributing you agree that your contribution is licensed under the MIT License of this project.
