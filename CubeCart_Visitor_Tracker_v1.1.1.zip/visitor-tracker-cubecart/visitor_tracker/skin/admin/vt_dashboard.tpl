<form action="{$VAL_SELF}" method="post" enctype="multipart/form-data">

<div id="vt_dashboard" class="tab_content">
  <h3>Visitor Tracker</h3>
  <div id="vt-root" data-payload="{$VT_PAYLOAD}">
    <div class="vt-bar">
      <span>Periode:</span>
      <a href="{$VT_BASE}&days=1">Vandaag</a>
      <a href="{$VT_BASE}&days=7">7 dagen</a>
      <a href="{$VT_BASE}&days=30">30 dagen</a>
      <a href="{$VT_BASE}&days=90">90 dagen</a>
      <span class="vt-live"><i></i> <b id="vt-live">0</b> nu actief</span>
    </div>
    <div class="vt-tiles" id="vt-tiles"></div>
    <div class="vt-grid">
      <div class="vt-card vt-wide"><h4>Bezoekers &amp; paginaweergaven per dag</h4><div class="vt-h"><canvas id="c-daily"></canvas></div></div>
      <div class="vt-card"><h4>Trechter (unieke bezoekers)</h4><div class="vt-h"><canvas id="c-funnel"></canvas></div></div>
      <div class="vt-card"><h4>Drukste uren</h4><div class="vt-h"><canvas id="c-hours"></canvas></div></div>
      <div class="vt-card"><h4>Meest bekeken producten</h4><div class="vt-h"><canvas id="c-products"></canvas></div></div>
      <div class="vt-card"><h4>Meest in winkelwagen gelegd</h4><div class="vt-h"><canvas id="c-carted"></canvas></div></div>
      <div class="vt-card"><h4>Populaire categorieen</h4><div class="vt-h"><canvas id="c-cats"></canvas></div></div>
      <div class="vt-card"><h4>Zoektermen</h4><div class="vt-h"><canvas id="c-search"></canvas></div></div>
      <div class="vt-card"><h4>Herkomst (verwijzers)</h4><div class="vt-h"><canvas id="c-ref"></canvas></div></div>
      <div class="vt-card"><h4>Apparaten</h4><div class="vt-h"><canvas id="c-dev"></canvas></div></div>
      <div class="vt-card vt-wide"><h4>Klikpad per bezoeker (laatste 2 dagen)</h4>
        <div class="vt-scroll"><table class="vt-table" id="vt-paths"><thead><tr><th>Laatst gezien</th><th>Apparaat</th><th>Acties</th><th>Pad</th></tr></thead><tbody></tbody></table></div>
      </div>
    </div>
  </div>
</div>

<div id="general" class="tab_content">
  <h3>Instellingen</h3>
  <fieldset>
    <div><label for="status">Status</label>
      <span><input type="hidden" name="module[status]" id="status" class="toggle" value="{$MODULE.status}"></span></div>
    <div><label for="vt_ret">Bewaartermijn (dagen)</label>
      <span><input type="text" name="module[retention_days]" id="vt_ret" class="textbox number" value="{if $MODULE.retention_days}{$MODULE.retention_days}{else}90{/if}"></span></div>
    <div><label for="vt_ex">IP-adressen uitsluiten</label>
      <span><input type="text" name="module[exclude_ips]" id="vt_ex" class="textbox" value="{$MODULE.exclude_ips}"> <small>kommagescheiden, bv. je eigen IP</small></span></div>
  </fieldset>
  <p><small>Er worden geen IP-adressen of cookies opgeslagen: een bezoeker is een anonieme hash die elke dag wisselt.</small></p>
</div>

<div class="form_control">
  <input type="submit" value="{$LANG.common.save}">
</div>
<input type="hidden" name="token" value="{$SESSION_TOKEN}">
</form>

<style>
{literal}
#vt-root{font-size:13px}
.vt-bar{display:flex;gap:10px;align-items:center;margin:8px 0 14px}
.vt-bar a{padding:4px 10px;border:1px solid #c8ccd0;border-radius:14px;text-decoration:none;color:#333;background:#fff}
.vt-bar a:hover{background:#eef3f8}
.vt-live{margin-left:auto;font-weight:600}
.vt-live i{display:inline-block;width:9px;height:9px;border-radius:50%;background:#2fb344;margin-right:4px;animation:vtp 1.6s infinite}
@keyframes vtp{50%{opacity:.25}}
.vt-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:14px}
.vt-tile{background:#fff;border:1px solid #dfe3e7;border-radius:8px;padding:12px 14px}
.vt-tile b{display:block;font-size:24px;margin-top:2px}
.vt-tile span{color:#6b7580}
.vt-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.vt-card{background:#fff;border:1px solid #dfe3e7;border-radius:8px;padding:12px 14px;min-width:0}
.vt-card h4{margin:0 0 8px;font-size:13px;color:#333}
.vt-wide{grid-column:1/-1}
.vt-h{position:relative;height:250px}
.vt-scroll{overflow-x:auto}
.vt-table{width:100%;border-collapse:collapse}
.vt-table th,.vt-table td{padding:6px 8px;border-bottom:1px solid #eceff2;text-align:left;vertical-align:top}
.vt-table td:last-child{word-break:break-word}
@media(max-width:900px){.vt-grid{grid-template-columns:1fr}}
{/literal}
</style>
<script src="{$VT_CHARTJS}"></script>
<script>
{literal}
(function(){
  var root=document.getElementById('vt-root'); if(!root||typeof Chart==='undefined')return;
  var d;
  try{ d=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(root.getAttribute('data-payload')),function(c){return c.charCodeAt(0)}))); }catch(e){ return; }
  var C=['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#64748b'];
  var nf=function(n){return Number(n).toLocaleString('nl-NL')};
  document.getElementById('vt-live').textContent=d.live;

  var f=d.funnel, conv=d.visitors?(f.complete/d.visitors*100):0;
  var tiles=[['Bezoekers',nf(d.visitors)],['Paginaweergaven',nf(d.pageviews)],['Pagina\'s / bezoeker',d.visitors?(d.pageviews/d.visitors).toFixed(1).replace('.',','):'0'],
             ['In winkelwagen',nf(f.cart_add)],['Bestellingen',nf(f.complete)],['Conversie',conv.toFixed(1).replace('.',',')+'%']];
  document.getElementById('vt-tiles').innerHTML=tiles.map(function(t){return '<div class="vt-tile"><span>'+t[0]+'</span><b>'+t[1]+'</b></div>'}).join('');

  var base={responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}};
  var days=Object.keys(d.daily);
  new Chart(document.getElementById('c-daily'),{type:'line',data:{labels:days.map(function(x){return x.slice(8)+'-'+x.slice(5,7)}),datasets:[
    {label:'Bezoekers',data:days.map(function(k){return d.daily[k].v}),borderColor:C[0],backgroundColor:C[0]+'33',fill:true,tension:.3},
    {label:'Paginaweergaven',data:days.map(function(k){return d.daily[k].p}),borderColor:C[1],tension:.3}]},
    options:Object.assign({},base,{plugins:{legend:{display:true}},scales:{y:{beginAtZero:true}}})});

  new Chart(document.getElementById('c-funnel'),{type:'bar',data:{labels:['Product bekeken','In winkelwagen','Checkout','Besteld'],
    datasets:[{data:[f.product,f.cart_add,f.checkout,f.complete],backgroundColor:C.slice(0,4)}]},
    options:Object.assign({},base,{indexAxis:'y',scales:{x:{beginAtZero:true}}})});

  new Chart(document.getElementById('c-hours'),{type:'bar',data:{labels:d.hours.map(function(_,i){return i+'u'}),
    datasets:[{data:d.hours,backgroundColor:C[4]}]},options:Object.assign({},base,{scales:{y:{beginAtZero:true}}})});

  function hbar(id,rows,color){
    new Chart(document.getElementById(id),{type:'bar',data:{labels:rows.map(function(r){var n=String(r.n);return n.length>38?n.slice(0,36)+'..':n}),
      datasets:[{data:rows.map(function(r){return +r.c}),backgroundColor:color}]},
      options:Object.assign({},base,{indexAxis:'y',scales:{x:{beginAtZero:true,ticks:{precision:0}}}})});
  }
  hbar('c-products',d.topProducts,C[0]); hbar('c-carted',d.topCarted,C[2]); hbar('c-cats',d.topCats,C[1]);
  hbar('c-search',d.topSearch,C[5]); hbar('c-ref',d.topRef,C[6]);

  new Chart(document.getElementById('c-dev'),{type:'doughnut',data:{labels:d.devices.map(function(r){return r.n}),
    datasets:[{data:d.devices.map(function(r){return +r.c}),backgroundColor:C}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right'}}}});

  var tb=document.querySelector('#vt-paths tbody');
  d.paths.forEach(function(p){
    var tr=document.createElement('tr');
    [p.last_seen,p.device,p.n,p.path].forEach(function(v){var td=document.createElement('td');td.textContent=v;tr.appendChild(td)});
    tb.appendChild(tr);
  });
})();
{/literal}
</script>
