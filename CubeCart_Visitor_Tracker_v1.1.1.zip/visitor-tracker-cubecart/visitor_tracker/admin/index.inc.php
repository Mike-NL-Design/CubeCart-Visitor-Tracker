<?php
// Bij een fout tonen we een korte melding (alleen zichtbaar voor beheerders)
$vt_show = function ($t, $m, $f, $l) {
    echo '<pre style="background:#fee;border:1px solid #c00;padding:10px;margin:10px;white-space:pre-wrap">Visitor Tracker fout: '
       . htmlspecialchars($t . ': ' . $m . ' (' . basename($f) . ':' . $l . ')') . '</pre>';
};
try {
/**
 * Visitor Tracker - admin controller + dashboard-data.
 *
 * @copyright 2026 MikeNL
 * @license   MIT (see LICENSE)
 * SPDX-License-Identifier: MIT
 */
if (!defined('CC_INI_SET')) { die('Access Denied'); }
Admin::getInstance()->permissions('settings', CC_PERM_EDIT, true);

$vt_dir  = dirname(__DIR__);
$vt_flag = $vt_dir . '/.installed2';

// ---- Tabelprefix bepalen (CubeCart-tabellen hebben een prefix, bv. cc_) -------
if (file_exists($vt_flag)) {
    $p = trim((string)file_get_contents($vt_flag));
} else {
    $p = '';
    $r = $GLOBALS['db']->query("SHOW TABLES LIKE '%CubeCart_inventory'");
    if (is_array($r) && !empty($r)) {
        $row  = reset($r);
        $name = (string)reset($row);
        $len  = strlen('CubeCart_inventory');
        if (substr($name, -$len) === 'CubeCart_inventory') { $p = substr($name, 0, -$len); }
    } elseif (!empty($GLOBALS['glob']['dbprefix'])) {
        $p = $GLOBALS['glob']['dbprefix'];
    }
    $p = preg_replace('/[^A-Za-z0-9_]/', '', $p);

    $GLOBALS['db']->query("CREATE TABLE IF NOT EXISTS {$p}CubeCart_vt_events (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ts DATETIME NOT NULL,
        visitor CHAR(16) NOT NULL,
        type VARCHAR(20) NOT NULL,
        ref_id INT UNSIGNED NOT NULL DEFAULT 0,
        label VARCHAR(150) NOT NULL DEFAULT '',
        url VARCHAR(250) NOT NULL DEFAULT '',
        referrer VARCHAR(100) NOT NULL DEFAULT '',
        device VARCHAR(10) NOT NULL DEFAULT '',
        KEY idx_ts (ts),
        KEY idx_type_ts (type, ts),
        KEY idx_visitor (visitor, ts)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Per ongeluk aangemaakte tabel zonder prefix (eerdere versie) opruimen
    if ($p !== '') { $GLOBALS['db']->query("DROP TABLE IF EXISTS CubeCart_vt_events"); }
    @file_put_contents($vt_flag, $p);
}

// ---- Dashboard-data --------------------------------------------------------
$days  = isset($_GET['days']) ? max(1, min(365, (int)$_GET['days'])) : 30;
$since = "ts >= DATE_SUB(NOW(), INTERVAL {$days} DAY)";

$q = function ($sql) {
    $r = $GLOBALS['db']->query($sql);
    return is_array($r) ? $r : [];
};

// Dagreeks (ontbrekende dagen opvullen met 0)
$daily = [];
for ($i = $days - 1; $i >= 0; $i--) { $daily[date('Y-m-d', strtotime("-{$i} day"))] = ['v' => 0, 'p' => 0]; }
foreach ($q("SELECT DATE(ts) d, COUNT(DISTINCT visitor) v, COUNT(*) p FROM {$p}CubeCart_vt_events
             WHERE {$since} AND type <> 'cart_add' GROUP BY DATE(ts)") as $r) {
    if (isset($daily[$r['d']])) { $daily[$r['d']] = ['v' => (int)$r['v'], 'p' => (int)$r['p']]; }
}

$hours = array_fill(0, 24, 0);
foreach ($q("SELECT HOUR(ts) h, COUNT(*) c FROM {$p}CubeCart_vt_events WHERE {$since} AND type <> 'cart_add' GROUP BY HOUR(ts)") as $r) {
    $hours[(int)$r['h']] = (int)$r['c'];
}

// Trechter (unieke bezoekers per stap)
$fun = ['product' => 0, 'cart_add' => 0, 'checkout' => 0, 'complete' => 0];
foreach ($q("SELECT type, COUNT(DISTINCT visitor) c FROM {$p}CubeCart_vt_events
             WHERE {$since} AND type IN ('product','cart_add','checkout','complete') GROUP BY type") as $r) {
    $fun[$r['type']] = (int)$r['c'];
}
$tot = $q("SELECT COUNT(DISTINCT visitor) v, SUM(type <> 'cart_add') p FROM {$p}CubeCart_vt_events WHERE {$since}");
$visitors  = (int)($tot[0]['v'] ?? 0);
$pageviews = (int)($tot[0]['p'] ?? 0);

$topProducts = $q("SELECT COALESCE(i.name, CONCAT('#', e.ref_id)) n, COUNT(*) c
    FROM {$p}CubeCart_vt_events e LEFT JOIN {$p}CubeCart_inventory i ON i.product_id = e.ref_id
    WHERE e.{$since} AND e.type = 'product' AND e.ref_id > 0 GROUP BY e.ref_id, i.name ORDER BY c DESC LIMIT 10");
$topCarted = $q("SELECT COALESCE(i.name, CONCAT('#', e.ref_id)) n, COUNT(*) c
    FROM {$p}CubeCart_vt_events e LEFT JOIN {$p}CubeCart_inventory i ON i.product_id = e.ref_id
    WHERE e.{$since} AND e.type = 'cart_add' GROUP BY e.ref_id, i.name ORDER BY c DESC LIMIT 10");
$topCats = $q("SELECT COALESCE(c.cat_name, CONCAT('#', e.ref_id)) n, COUNT(*) c
    FROM {$p}CubeCart_vt_events e LEFT JOIN {$p}CubeCart_category c ON c.cat_id = e.ref_id
    WHERE e.{$since} AND e.type = 'category' AND e.ref_id > 0 GROUP BY e.ref_id, c.cat_name ORDER BY c DESC LIMIT 10");
$topSearch = $q("SELECT label n, COUNT(*) c FROM {$p}CubeCart_vt_events
    WHERE {$since} AND type = 'search' AND label <> '' GROUP BY label ORDER BY c DESC LIMIT 10");
$topRef = $q("SELECT referrer n, COUNT(DISTINCT visitor) c FROM {$p}CubeCart_vt_events
    WHERE {$since} AND referrer <> '' GROUP BY referrer ORDER BY c DESC LIMIT 10");
$devices = $q("SELECT device n, COUNT(DISTINCT visitor) c FROM {$p}CubeCart_vt_events
    WHERE {$since} AND device <> '' GROUP BY device ORDER BY c DESC");
$entry = $q("SELECT url n, COUNT(*) c FROM {$p}CubeCart_vt_events
    WHERE {$since} AND type <> 'cart_add' GROUP BY url ORDER BY c DESC LIMIT 10");

// Live: afgelopen 5 minuten
$live = $q("SELECT COUNT(DISTINCT visitor) v FROM {$p}CubeCart_vt_events WHERE ts >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
$liveNow = (int)($live[0]['v'] ?? 0);

// Klikpad per bezoeker (laatste 25)
$paths = $q("SELECT visitor, MIN(ts) first_seen, MAX(ts) last_seen, COUNT(*) n, MAX(device) device,
    GROUP_CONCAT(CONCAT_WS(': ', type, NULLIF(label, '')) ORDER BY ts SEPARATOR ' > ') path
    FROM {$p}CubeCart_vt_events WHERE ts >= DATE_SUB(NOW(), INTERVAL 2 DAY)
    GROUP BY visitor ORDER BY last_seen DESC LIMIT 25");
foreach ($paths as &$vt_row) { $vt_row["path"] = function_exists('mb_substr') ? mb_substr((string)$vt_row['path'], 0, 400) : substr((string)$vt_row['path'], 0, 400); }
unset($vt_row);

$payload = [
    'days' => $days, 'visitors' => $visitors, 'pageviews' => $pageviews, 'live' => $liveNow,
    'daily' => $daily, 'hours' => $hours, 'funnel' => $fun,
    'topProducts' => $topProducts, 'topCarted' => $topCarted, 'topCats' => $topCats,
    'topSearch' => $topSearch, 'topRef' => $topRef, 'devices' => $devices, 'pages' => $entry,
    'paths' => $paths,
];
// base64 om Smarty-escaping en HTML-problemen te omzeilen
$GLOBALS['smarty']->assign('VT_PAYLOAD', base64_encode(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE)));
$GLOBALS['smarty']->assign('VT_CHARTJS', CC_ROOT_REL . 'modules/plugins/visitor_tracker/skin/admin/chart.umd.js');
$GLOBALS['smarty']->assign('VT_BASE', '?_g=plugins&type=plugins&module=visitor_tracker');
$GLOBALS['smarty']->assign('VT_DAYS', $days);

$GLOBALS['main']->addTabControl('Dashboard', 'vt_dashboard');
$GLOBALS['main']->addTabControl('Instellingen', 'general');

$module = new Module(__FILE__, $GLOBALS['_GET']['module'], 'admin/vt_dashboard.tpl', true, true);
$page_content = $module->display();

} catch (Throwable $e) {
    $vt_show(get_class($e), $e->getMessage(), $e->getFile(), $e->getLine());
    if (!isset($page_content)) { $page_content = ''; }
}
