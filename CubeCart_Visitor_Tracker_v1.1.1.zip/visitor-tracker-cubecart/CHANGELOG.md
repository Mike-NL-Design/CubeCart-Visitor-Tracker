# Changelog

All notable changes to this project are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [1.2.0] - 2026-10-24

First public release.

### Added
- Frontend tracking via the `class.cubecart.construct` hook: home, product, category, search, basket, checkout, completed order, documents and other pages, plus "add to cart" events.
- Privacy-friendly visitor identification: daily rotating anonymous hash, no cookies, no IP addresses or user agents stored.
- Bot and crawler filtering, optional IP exclusion list and automatic data retention cleanup (default 90 days).
- Admin dashboard with Chart.js (bundled, no external requests): visitors and page views per day, busiest hours, conversion funnel, top products, top "added to cart", top categories, search terms, referrers, devices, live counter and click path per visitor.
- Menu item "Bezoekers" under "Rapportage" via the `admin.navigation` hook.
- Settings tab: status, retention period, excluded IP addresses.
- Automatic detection of the database table prefix; tables are created on first dashboard visit.
- Documentation in English and Dutch (`README.md`, `README.nl.md`), MIT license.
