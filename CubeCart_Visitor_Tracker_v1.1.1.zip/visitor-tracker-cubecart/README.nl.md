# Visitor Tracker voor CubeCart

Een privacyvriendelijke bezoekersstatistiek-plugin voor **CubeCart 6**. De plugin legt vast wat bezoekers in je webshop doen (pagina's, producten, categorieën, zoekopdrachten, toevoegen aan winkelwagen, checkout en afgeronde bestellingen) en toont dat in een grafisch dashboard in het beheer.

- Dashboard met grafieken (Chart.js zit erbij, er wordt niets van externe servers geladen)
- Bezoekers en paginaweergaven per dag, drukste uren, trechter van bezoek tot bestelling
- Meest bekeken producten, meest in winkelwagen gelegd, populaire categorieën, zoektermen
- Herkomst van bezoekers (verwijzers), apparaten, live teller "nu actief"
- Klikpad per bezoeker (laatste 2 dagen)
- Menu-item **Bezoekers** in het linkermenu van het beheer, onder **Rapportage**
- Geen cookies en geen IP-adressen opgeslagen (zie Privacy)

> De Engelse versie van deze handleiding staat in `README.md`.

## Vereisten

- CubeCart 6.x
- PHP 7.4 of nieuwer (ontwikkeld voor en gebruikt op PHP 8.4)
- MySQL/MariaDB (de plugin maakt één tabel aan)
- Toegang tot je server via FTP of bestandsbeheer

## Installatie

1. Download de nieuwste `visitor_tracker.zip` via de Releases-pagina en pak hem uit. Je krijgt een map `visitor_tracker`. (Heb je de repository gekloond, dan heb je alleen de map `visitor_tracker/` nodig.)
2. Upload die map naar `modules/plugins/` op je server. Het resultaat moet zijn:

   ```
   modules/plugins/visitor_tracker/config.xml
   modules/plugins/visitor_tracker/admin/index.inc.php
   modules/plugins/visitor_tracker/hooks/admin.navigation.php
   modules/plugins/visitor_tracker/hooks/class.cubecart.construct.php
   modules/plugins/visitor_tracker/language/module.definitions.xml
   modules/plugins/visitor_tracker/skin/admin/chart.umd.js
   modules/plugins/visitor_tracker/skin/admin/vt_dashboard.tpl
   ```

   Zorg dat er **geen extra map** omheen zit (dus niet `visitor_tracker/visitor_tracker/config.xml`), anders vindt CubeCart de plugin niet.
3. Ga in het beheer naar **Extensions > Plugins**. *Visitor Tracker* staat nu in de lijst met naam en versienummer.
4. Zet de plugin op **Enabled**.
5. Ga naar **Settings > Manage Hooks** en controleer dat *Visitor Tracker* twee hooks heeft: `class.cubecart.construct` en `admin.navigation`, allebei op Enabled. Staan ze er niet, klik dan op "Terugzetten naar standaard hook-configuratie".
6. **Open het dashboard één keer** (Extensions > Plugins > Visitor Tracker, of het nieuwe menu-item). Hierbij wordt de databasetabel aangemaakt en de tracking aangezet. Vóór deze stap wordt er niets vastgelegd.
7. Maak de cache van CubeCart leeg (verwijder de bestanden in `cache/`, niet de mappen) en ververs het beheer met Ctrl+F5. Het menu-item **Bezoekers** staat nu onder **Rapportage**.

## Gebruik

- Open het dashboard via het menu-item **Bezoekers** (of via Extensions > Plugins > Visitor Tracker).
- Kies bovenaan de periode: vandaag, 7, 30 of 90 dagen.
- Tabblad **Instellingen**:
  - **Status**: de plugin aan of uit zetten
  - **Bewaartermijn (dagen)**: hoe lang gegevens bewaard blijven (standaard 90 dagen, minimaal 7). Oudere gegevens worden automatisch verwijderd.
  - **IP-adressen uitsluiten**: kommagescheiden IP-adressen die niet worden meegeteld, bijvoorbeeld je eigen adres.

Testen: bezoek je shop in een privévenster, bekijk een product, leg het in de winkelwagen en ververs het dashboard. De teller "nu actief" moet dan minimaal 1 tonen.

## Privacy

- Er worden geen cookies geplaatst en er worden geen IP-adressen of browsernamen opgeslagen.
- Een bezoeker is een anonieme hash van IP + browser + datum + serverpad die **elke dag verandert**. Een terugkerende bezoeker op een andere dag telt dus als nieuwe bezoeker.
- Bekende bots en crawlers (zoekmachines, SEO-tools, monitoringdiensten) worden genegeerd.
- Omdat er geen persoonsgegevens worden opgeslagen is meestal geen cookiebanner nodig, maar de regels verschillen per land en situatie. Controleer dit voor je eigen shop en noem de statistieken in je privacyverklaring.

## Problemen oplossen

**De plugin staat niet in de pluginlijst**
Controleer dat `config.xml` direct in `modules/plugins/visitor_tracker/` staat (geen extra map) en volledig is geüpload. Test het door `https://jouw-shop/modules/plugins/visitor_tracker/config.xml` in een browser te openen. Maak ook de cache leeg.

**"Invalid module details" bij het inschakelen**
`config.xml` kon niet worden gelezen. Upload het bestand opnieuw uit de zip.

**Witte pagina bij het openen van het dashboard**
Er is een PHP-fout die niet wordt getoond. Kijk in het foutenlogboek van je hosting. Heb je een templatebestand aangepast, verwijder dan ook de gecompileerde templates in `cache/skin/`, want Smarty kan een oude gecompileerde versie blijven gebruiken.

**Het menu-item "Bezoekers" verschijnt niet**
Controleer bij *Settings > Manage Hooks* of de hook `admin.navigation` er staat, maak de cache leeg en ververs met Ctrl+F5. Het item wordt toegevoegd aan de groep *Rapportage* (of een groep met "report" of "statistics" in de naam). Heet jouw menugroep anders, dan maakt de plugin een groep *Rapportage* aan.

**Het dashboard blijft leeg**
- Heb je het dashboard na het inschakelen één keer geopend? (Daarbij wordt het verborgen bestand `.installed2` in de pluginmap aangemaakt; sommige FTP-programma's verbergen bestanden die met een punt beginnen.)
- Staat je eigen IP-adres in de uitsluitlijst?
- Staat de hook `class.cubecart.construct` op Enabled in *Manage Hooks*?
- Gebruik je voor het testen een gewone browser (geen script of programma met "bot" in de naam)?

**Veel bezoeken 's nachts**
Sommige scrapers gebruiken een gewone browsernaam en zijn niet te herkennen. Zie je in de grafiek "Drukste uren" een piek 's nachts, dan zijn dat waarschijnlijk geen echte klanten.

## Verwijderen

1. Zet de plugin op **Disabled** in Extensions > Plugins.
2. Verwijder de map `modules/plugins/visitor_tracker`.
3. Wil je ook de gegevens weghalen: verwijder dan in phpMyAdmin de tabel `<jouw prefix>CubeCart_vt_events` (bijvoorbeeld `cc_CubeCart_vt_events`).

## Opmerkingen en beperkingen

- Paginatypen worden herkend aan de eigen verzoekparameters van CubeCart, dus het werkt ook met SEO-vriendelijke urls. Niet herkende pagina's worden opgeslagen als "overig" met hun interne paginanaam.
- Tijdstippen gebruiken de tijdzone van de PHP-server.
- Bestelwaarde en omzet worden in deze versie niet bijgehouden.
- Dit is een onafhankelijke plugin en geen officieel CubeCart-product. Test hem eerst op een kopie van je shop en maak een back-up.

## Licentie

Uitgegeven onder de [MIT-licentie](LICENSE). Copyright (c) 2026 MikeNL.
De meegeleverde bibliotheek Chart.js heeft ook een MIT-licentie, zie [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

CubeCart is een handelsmerk van de rechthebbende. Deze plugin is een onafhankelijk project en is niet verbonden aan of goedgekeurd door CubeCart Limited.

## Credits

- Plugin door MikeNL.
- [Chart.js](https://www.chartjs.org/) 4.4.7 (MIT-licentie) wordt meegeleverd voor de grafieken.
