# Third-party notices

This plugin bundles the following third-party software.

## Chart.js 4.4.7

- File: `skin/admin/chart.umd.js`
- Source: https://www.chartjs.org / https://github.com/chartjs/Chart.js
- License: MIT

```
The MIT License (MIT)

Copyright (c) 2014-2024 Chart.js Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

## MaxMind DB Reader for PHP 1.15.0

- Files: `lib/MaxMind/` (unmodified copy of `src/MaxMind`) and `lib/LICENSE-MaxMind-DB-Reader-Apache-2.0.txt`
- Source: https://github.com/maxmind/MaxMind-DB-Reader-php (package `maxmind-db/reader`, by Gregory J. Oschwald / MaxMind)
- License: Apache License 2.0 (full text in `lib/LICENSE-MaxMind-DB-Reader-Apache-2.0.txt`)
- Used to look up the country of a visitor in a local `.mmdb` GeoIP database. No data is sent to any server.

## GeoIP databases (not included)

The plugin does not ship a GeoIP database. If you add one to `geoip/`, its own license applies:

- DB-IP "IP to Country Lite": CC BY 4.0, attribution required (https://db-ip.com). The dashboard shows the attribution automatically when a DB-IP file is used.
- MaxMind GeoLite2 Country: MaxMind GeoLite2 End User License Agreement (https://www.maxmind.com).

buymeacoffee.com/nlbiertjenl
