# Visitor Tracker voor CubeCart

buymeacoffee.com/nlbiertjenl

Een privacyvriendelijke bezoekersstatistiek-plugin voor **CubeCart 6**. De plugin legt vast wat bezoekers in je webshop doen en toont dat in een grafisch dashboard in het beheer, samen met de omzet per product uit je eigen bestellingen.

- Dashboard met grafieken (Chart.js zit erbij, er wordt niets van externe servers geladen)
- Bezoekers en paginaweergaven per dag, drukste uren, trechter van bezoek tot bestelling
- Meest bekeken producten, meest in winkelwagen gelegd, populaire categorieën, zoektermen, herkomst, apparaten
- **Omzet per product** (bekeken, in winkelwagen, verkocht, omzet) en omzet per dag, uit je CubeCart-bestellingen
- **Landen van bezoekers** via een lokale GeoIP-database (of Cloudflare), zonder IP-adressen op te slaan
- **Verlaten winkelwagens**: gestart en verlaten per dag en per product, plus onbetaalde bestellingen
- **CSV-export** van elk rapport (Excel-NL of standaard formaat)
- Live teller "nu actief" en klikpad per bezoeker
- Menu-item **Bezoekers** in het linkermenu van het beheer, onder **Rapportage**
- Geen cookies en geen IP-adressen opgeslagen (zie Privacy)

> De Engelse versie van deze handleiding staat in `README.md`.

## Vereisten

- CubeCart 6.x
- PHP 7.4 of nieuwer (ontwikkeld voor en gebruikt op PHP 8.4)
- MySQL/MariaDB (de plugin maakt één tabel aan)
- Toegang tot je server via FTP of bestandsbeheer
- Optioneel: een gratis GeoIP-landendatabase voor de landen van bezoekers (zie GeoIP)

## Installatie

1. Download de nieuwste `visitor_tracker.zip` via de Releases-pagina en pak hem uit. Je krijgt een map `visitor_tracker`. (Heb je de repository gekloond, dan heb je alleen de map `visitor_tracker/` nodig.)
2. Upload die map naar `modules/plugins/` op je server. Het resultaat moet zijn:

   ```
   modules/plugins/visitor_tracker/config.xml
   modules/plugins/visitor_tracker/admin/index.inc.php
   modules/plugins/visitor_tracker/admin/vt_data.inc.php
   modules/plugins/visitor_tracker/hooks/admin.navigation.php
   modules/plugins/visitor_tracker/hooks/class.cubecart.construct.php
   modules/plugins/visitor_tracker/language/module.definitions.xml
   modules/plugins/visitor_tracker/skin/admin/chart.umd.js
   modules/plugins/visitor_tracker/skin/admin/vt_overview.tpl
   modules/plugins/visitor_tracker/lib/MaxMind/...
   modules/plugins/visitor_tracker/geoip/README.txt
   ```

   Zorg dat er **geen extra map** omheen zit (dus niet `visitor_tracker/visitor_tracker/config.xml`), anders vindt CubeCart de plugin niet.
3. Ga in het beheer naar **Extensions > Plugins**. *Visitor Tracker* staat nu in de lijst met naam en versienummer.
4. Zet de plugin op **Enabled**.
5. Ga naar **Settings > Manage Hooks** en controleer dat *Visitor Tracker* twee hooks heeft: `class.cubecart.construct` en `admin.navigation`, allebei op Enabled. Staan ze er niet, klik dan op "Terugzetten naar standaard hook-configuratie".
6. **Open het dashboard één keer** (Extensions > Plugins > Visitor Tracker, of het nieuwe menu-item). Hierbij wordt de databasetabel aangemaakt en de tracking aangezet. Vóór deze stap wordt er niets vastgelegd.
7. Maak de cache van CubeCart leeg (verwijder de bestanden in `cache/`, niet de mappen) en ververs het beheer met Ctrl+F5. Het menu-item **Bezoekers** staat nu onder **Rapportage**.

### Bijwerken vanaf een eerdere versie (1.0 - 1.2)

1. Upload de nieuwe bestanden over de oude. Verwijder de oude template `skin/admin/vt_dashboard.tpl` (die is vervangen door `vt_overview.tpl`).
2. Maak de cache leeg, ook de gecompileerde templates in `cache/skin/`.
3. Open het dashboard één keer. De database wordt automatisch bijgewerkt (er komt een kolom `country` bij; bestaande gegevens blijven behouden).
4. Optioneel: voeg een GeoIP-database toe (zie hieronder) om landen vast te leggen. Bezoeken van vóór die tijd hebben geen land.

## Gebruik

Open het dashboard via het menu-item **Bezoekers** (of via Extensions > Plugins > Visitor Tracker). Kies bovenaan de periode (vandaag = laatste 24 uur, 7, 30 of 90 dagen). De onderdelen:

- **Overzicht**: bezoekers, paginaweergaven, trechter, drukste uren, topproducten, categorieën, zoektermen, verwijzers, apparaten en het klikpad per bezoeker.
- **Producten & omzet**: omzet en bestellingen per dag, topproducten naar omzet en een tabel met bekeken, in winkelwagen, verkocht, omzet en verkocht per 100 keer bekeken.
- **Landen**: bezoekers, paginaweergaven en kopers per land.
- **Winkelwagens**: gestarte en verlaten winkelwagens per dag en per product, en onbetaalde bestellingen.
- **Export**: CSV-downloads (zie hieronder).

Tabblad **Instellingen**:
- **Status**: de plugin aan of uit zetten
- **Bewaartermijn (dagen)**: hoe lang gegevens bewaard blijven (standaard 90 dagen, minimaal 7). Oudere gegevens worden automatisch verwijderd.
- **IP-adressen uitsluiten**: kommagescheiden IP-adressen die niet worden meegeteld, bijvoorbeeld je eigen adres.

Testen: bezoek je shop in een privévenster, bekijk een product, leg het in de winkelwagen en ververs het dashboard. De teller "nu actief" moet dan minimaal 1 tonen.

### Omzet per product

De omzet komt uit de CubeCart-tabellen `order_summary` en `order_inventory`, niet uit de tracker. Alleen betaalde bestellingen tellen mee (status *Processing* of *Complete*). De omzet per product is de opgeslagen regelprijs maal het aantal, dus **zonder btw, verzendkosten en kortingen**. De tegel met totale omzet gebruikt de ordertotalen. Alle bedragen staan in de standaardvaluta van de shop; accepteer je meerdere valuta's, dan worden de sommen niet omgerekend. Worden de ordertabellen niet gevonden (bijvoorbeeld in een heel andere CubeCart-versie), dan toont de plugin een melding en blijven de andere rapporten gewoon werken.

### Landen van bezoekers (GeoIP)

Het land wordt op de server bepaald op het moment van de paginaweergave. Alleen de landcode van 2 letters wordt opgeslagen, nooit het IP-adres, en er wordt niets naar een externe dienst gestuurd.

1. Download de gratis database **IP to Country Lite** (MMDB-formaat) van https://db-ip.com/db/download/ip-to-country-lite. (Alternatief: MaxMind GeoLite2 Country, daarvoor heb je een gratis account nodig.)
2. Zet het `.mmdb`-bestand (of het `.mmdb.gz`, dat bij het openen van het dashboard automatisch wordt uitgepakt) in `modules/plugins/visitor_tracker/geoip/`. Er mag maar één `.mmdb`-bestand staan.
3. Nieuwe bezoeken krijgen nu een land. Werk het bestand elke paar maanden bij.

Staat je shop achter Cloudflare (of CloudFront), dan wordt de landenheader van die dienst gebruikt en is geen database nodig. Zonder beide blijft het onderdeel *Landen* leeg. De licentie van DB-IP Lite (CC BY 4.0) vraagt om bronvermelding; het dashboard toont die automatisch als een DB-IP-bestand wordt gebruikt.

### Verlaten winkelwagens

Een bezoeker telt als *verlaten* als hij een product in de winkelwagen legde (of bij de checkout kwam) maar dezelfde dag niet op de bestelling-voltooid-pagina kwam. Omdat de anonieme bezoeker-ID elke dag wisselt, telt iemand die vóór middernacht in de winkelwagen legt en erna betaalt als verlaten. Het onderdeel toont ook **onbetaalde bestellingen** (status *Pending*) ouder dan een uur; daar zitten ook bestellingen bij die op een bankoverschrijving wachten.

### CSV-export

Het tabblad *Export* biedt: per dag, alle producten, landen, verlaten winkelwagens per product, zoektermen, verwijzers en losse gebeurtenissen (max. 50.000 regels, zonder IP-adressen). Kies **Excel (NL)** voor bestanden met puntkomma als scheidingsteken en decimale komma (opent goed in Nederlandse Excel), of **Standaard** voor komma's en decimale punten. Cellen die beginnen met `= + - @` krijgen een apostrof ervoor, zodat zoektermen nooit als formule in een spreadsheet kunnen worden uitgevoerd.

## Privacy

- Er worden geen cookies geplaatst en er worden geen IP-adressen of browsernamen opgeslagen.
- Een bezoeker is een anonieme hash van IP + browser + datum + serverpad die **elke dag verandert**. Een terugkerende bezoeker op een andere dag telt dus als nieuwe bezoeker.
- Het land (2 letters) wordt op het moment van het bezoek uit het IP-adres afgeleid en in plaats daarvan opgeslagen.
- Bekende bots en crawlers (zoekmachines, SEO-tools, monitoringdiensten) worden genegeerd.
- Omdat er geen persoonsgegevens worden opgeslagen is meestal geen cookiebanner nodig, maar de regels verschillen per land en situatie. Controleer dit voor je eigen shop en noem de statistieken in je privacyverklaring.
- De lijst met onbetaalde bestellingen toont alleen bestelnummer, datum en totaal, geen klantgegevens.

## Problemen oplossen

**De plugin staat niet in de pluginlijst**
Controleer dat `config.xml` direct in `modules/plugins/visitor_tracker/` staat (geen extra map) en volledig is geüpload. Test het door `https://jouw-shop/modules/plugins/visitor_tracker/config.xml` in een browser te openen. Maak ook de cache leeg.

**"Invalid module details" bij het inschakelen**
`config.xml` kon niet worden gelezen. Upload het bestand opnieuw uit de zip.

**Witte pagina bij het openen van het dashboard**
Er is een PHP-fout die niet wordt getoond. Kijk in het foutenlogboek van je hosting. Heb je een templatebestand aangepast, verwijder dan ook de gecompileerde templates in `cache/skin/`, want Smarty kan een oude gecompileerde versie blijven gebruiken.

**Het menu-item "Bezoekers" verschijnt niet**
Controleer bij *Settings > Manage Hooks* of de hook `admin.navigation` er staat, maak de cache leeg en ververs met Ctrl+F5. Het item wordt toegevoegd aan de groep *Rapportage* (of een groep met "report" of "statistics" in de naam). Heet jouw menugroep anders, dan maakt de plugin een groep *Rapportage* aan.

**Het dashboard blijft leeg**
- Heb je het dashboard na het inschakelen één keer geopend? (Daarbij wordt het verborgen bestand `.installed2` in de pluginmap aangemaakt; sommige FTP-programma's verbergen bestanden die met een punt beginnen.)
- Staat je eigen IP-adres in de uitsluitlijst?
- Staat de hook `class.cubecart.construct` op Enabled in *Manage Hooks*?
- Gebruik je voor het testen een gewone browser (geen script of programma met "bot" in de naam)?

**Het onderdeel Landen is leeg**
Voeg een GeoIP-database toe aan `geoip/` (zie hierboven) en zorg dat er maar één `.mmdb`-bestand staat. Alleen bezoeken daarna krijgen een land. Een beschadigd databasebestand breekt de shop nooit: bezoeken worden dan gewoon vastgelegd, alleen zonder land.

**Er wordt geen omzet getoond**
De plugin leest de eigen ordertabellen van CubeCart. Controleer of er in de gekozen periode betaalde bestellingen zijn (status Processing of Complete). Staat er een melding dat de ordergegevens niet zijn gevonden, open dan een issue met je CubeCart-versie.

**Geen verlaten winkelwagens terwijl bezoekers wel producten toevoegden**
"In winkelwagen" wordt herkend aan het veld `add` van het toevoegverzoek. Gebruikt jouw skin een ander formulier, open dan een issue.

**Veel bezoeken 's nachts**
Sommige scrapers gebruiken een gewone browsernaam en zijn niet te herkennen. Zie je in de grafiek "Drukste uren" een piek 's nachts, dan zijn dat waarschijnlijk geen echte klanten.

## Verwijderen

1. Zet de plugin op **Disabled** in Extensions > Plugins.
2. Verwijder de map `modules/plugins/visitor_tracker`.
3. Wil je ook de gegevens weghalen: verwijder dan in phpMyAdmin de tabel `<jouw prefix>CubeCart_vt_events` (bijvoorbeeld `cc_CubeCart_vt_events`).

## Opmerkingen en beperkingen

- Paginatypen worden herkend aan de eigen verzoekparameters van CubeCart, dus het werkt ook met SEO-vriendelijke urls. Niet herkende pagina's worden opgeslagen als "overig" met hun interne paginanaam.
- Tijdstippen gebruiken de tijdzone van de PHP-server.
- Bezoeker-ID's wisselen dagelijks, dus er zijn geen meerdaagse bezoekersreizen of statistieken over terugkerende bezoekers.
- Omzet wordt niet tussen valuta's omgerekend.
- Dit is een onafhankelijke plugin en geen officieel CubeCart-product. Test hem eerst op een kopie van je shop en maak een back-up.

## Licentie

Uitgegeven onder de [MIT-licentie](LICENSE). Copyright (c) 2026 MikeNL.
De meegeleverde bibliotheken Chart.js (MIT) en MaxMind DB Reader voor PHP (Apache-2.0) houden hun eigen licentie, zie [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

CubeCart is een handelsmerk van de rechthebbende. Deze plugin is een onafhankelijk project en is niet verbonden aan of goedgekeurd door CubeCart Limited.

## Credits

- Plugin door MikeNL.
- [Chart.js](https://www.chartjs.org/) 4.4.7 voor de grafieken.
- [MaxMind DB Reader for PHP](https://github.com/maxmind/MaxMind-DB-Reader-php) 1.15.0 voor GeoIP-opzoekingen.
- Landgegevens (optioneel, niet meegeleverd): [DB-IP](https://db-ip.com) IP to Country Lite of MaxMind GeoLite2.
