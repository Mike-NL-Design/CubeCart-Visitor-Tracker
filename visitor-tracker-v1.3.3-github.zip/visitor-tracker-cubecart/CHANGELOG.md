# Changelog - buymeacoffee.com/nlbiertjenl

All notable changes to this project are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [1.3.3] - 2026-10-28

### Changed
- Charts without data (for example popular categories when nobody visited a category page) now show "Geen gegevens in deze periode." instead of an empty chart with only an axis.

## [1.3.2] - 2026-10-28

### Changed
- Plugin metadata in `config.xml`: removed the personal website from the homepage field and the unique id (`uid` is now `visitor-tracker-cubecart`). The homepage field is empty so you can set it to your own repository URL.

## [1.3.1] - 2026-10-28

### Fixed
- The click path per visitor now shows the name of the product or category (it only showed "product" / "category" before). Works for data that was already recorded. The raw-events CSV export gets the same name column.

## [1.3.0] - 2026-10-24

### Added
- **Revenue per product**: views, added to cart, units sold and revenue (excl. VAT) per product, plus revenue and orders per day, read from the CubeCart order tables (paid orders only). The plugin checks that the order tables and columns exist and degrades gracefully when they do not.
- **Visitor countries**: country code per visit via a local GeoIP `.mmdb` database (DB-IP Lite or MaxMind GeoLite2, not included) or the Cloudflare/CloudFront country header. Only the 2-letter code is stored, never the IP address. `.mmdb.gz` files are unpacked automatically. Bundled MaxMind DB Reader for PHP 1.15.0 (Apache-2.0, unmodified).
- **Abandoned carts**: carts started vs. abandoned per day and per product, checkout reached but not completed, and unpaid shop orders (status Pending, older than one hour).
- **CSV export** for days, products, countries, abandoned carts, search terms, referrers and raw events, in Excel-NL (`;`, decimal comma) or standard format. Formula injection protection for spreadsheet cells.
- Dashboard split into tabs (Overzicht, Producten & omzet, Landen, Winkelwagens, Export); charts are built when a tab is opened; the selected tab survives a period change.
- Automatic database upgrade (schema 2: `country` column and index) the first time the dashboard is opened; the tracking hook keeps working before the upgrade.

### Changed
- Dashboard template renamed to `vt_overview.tpl` (delete the old `vt_dashboard.tpl` and clear `cache/skin/`).
- Queries moved to `admin/vt_data.inc.php`; the controller only wires them together.
- A corrupt or unreadable GeoIP file no longer prevents a visit from being recorded.
- Bot filter extended.

## [1.2.0] - 2026-10-24

First public release (first version published on GitHub).

### Added
- Frontend tracking via the `class.cubecart.construct` hook: home, product, category, search, basket, checkout, completed order, documents and other pages, plus "add to cart" events.
- Privacy-friendly visitor identification: daily rotating anonymous hash, no cookies, no IP addresses or user agents stored.
- Bot and crawler filtering, optional IP exclusion list and automatic data retention cleanup (default 90 days).
- Admin dashboard with Chart.js (bundled, no external requests): visitors and page views per day, busiest hours, conversion funnel, top products, top "added to cart", top categories, search terms, referrers, devices, live counter and click path per visitor.
- Menu item "Bezoekers" under "Rapportage" via the `admin.navigation` hook.
- Settings tab: status, retention period, excluded IP addresses.
- Automatic detection of the database table prefix; tables are created on first dashboard visit.
- Documentation in English and Dutch (`README.md`, `README.nl.md`), MIT license.
