GeoIP database (optional) - landen van bezoekers
================================================

Zonder database slaat de plugin geen landen op (behalve als je shop achter
Cloudflare staat: dan wordt de header CF-IPCountry gebruikt).

Gratis en zonder account:
  1. Ga naar https://db-ip.com/db/download/ip-to-country-lite
  2. Download "IP to Country Lite" in het MMDB-formaat (.mmdb of .mmdb.gz).
  3. Zet het bestand in deze map (modules/plugins/visitor_tracker/geoip/).
     Een .mmdb.gz wordt bij het openen van het dashboard automatisch uitgepakt.

Alternatief: GeoLite2-Country.mmdb van MaxMind (gratis account nodig).

Er mag maar een .mmdb bestand in deze map staan. Werk het bestand elke paar
maanden bij. Het IP-adres wordt nooit opgeslagen, alleen de landcode (bv. NL).

Licenties: DB-IP Lite (CC BY 4.0) vraagt om bronvermelding, dat toont het
dashboard automatisch. GeoLite2 valt onder de MaxMind-voorwaarden.
