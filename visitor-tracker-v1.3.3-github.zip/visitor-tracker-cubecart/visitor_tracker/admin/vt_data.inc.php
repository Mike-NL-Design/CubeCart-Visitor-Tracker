<?php
/**
 * Visitor Tracker - data layer: all queries for the dashboard and the CSV export.
 *
 * @copyright 2026 MikeNL
 * @license   MIT (see LICENSE)
 * SPDX-License-Identifier: MIT
 */
if (!defined('CC_INI_SET')) { die('Access Denied'); }

if (!function_exists('vt_q')) {

    /** Run a query and always return an array of rows. */
    function vt_q($sql)
    {
        try { $r = $GLOBALS['db']->query($sql); } catch (Throwable $e) { return []; }
        return is_array($r) ? $r : [];
    }

    function vt_since($days, $alias = '')
    {
        $a = $alias === '' ? '' : $alias . '.';
        return $a . 'ts >= DATE_SUB(NOW(), INTERVAL ' . (int)$days . ' DAY)';
    }

    function vt_order_since($days, $alias = '')
    {
        $a = $alias === '' ? '' : $alias . '.';
        return $a . 'order_date >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL ' . (int)$days . ' DAY))';
    }

    /** Does the table exist and contain all these columns? (avoids SQL errors on other CubeCart versions) */
    function vt_has_cols($table, array $cols)
    {
        static $cache = [];
        if (!isset($cache[$table])) {
            $cache[$table] = [];
            if (vt_q("SHOW TABLES LIKE '" . $table . "'")) {
                foreach (vt_q("SHOW COLUMNS FROM `" . $table . "`") as $r) {
                    $cache[$table][] = strtolower((string)($r['Field'] ?? ''));
                }
            }
        }
        foreach ($cols as $c) {
            if (!in_array($c, $cache[$table], true)) { return false; }
        }
        return true;
    }

    /** Flag file: "<prefix>|<schema>" (older versions: just "<prefix>"). */
    function vt_read_flag($file)
    {
        if (!file_exists($file)) { return null; }
        $parts = explode('|', trim((string)@file_get_contents($file)));
        return ['p' => preg_replace('/[^A-Za-z0-9_]/', '', $parts[0]), 'schema' => (int)($parts[1] ?? 1)];
    }

    function vt_write_flag($file, $p, $schema)
    {
        @file_put_contents($file, $p . '|' . (int)$schema);
    }

    function vt_detect_prefix()
    {
        $p = '';
        $r = vt_q("SHOW TABLES LIKE '%CubeCart_inventory'");
        if ($r) {
            $row  = reset($r);
            $name = (string)reset($row);
            $len  = strlen('CubeCart_inventory');
            if (substr($name, -$len) === 'CubeCart_inventory') { $p = substr($name, 0, -$len); }
        } elseif (!empty($GLOBALS['glob']['dbprefix'])) {
            $p = (string)$GLOBALS['glob']['dbprefix'];
        }
        return preg_replace('/[^A-Za-z0-9_]/', '', $p);
    }

    function vt_create_table($p)
    {
        $GLOBALS['db']->query("CREATE TABLE IF NOT EXISTS {$p}CubeCart_vt_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            ts DATETIME NOT NULL,
            visitor CHAR(16) NOT NULL,
            type VARCHAR(20) NOT NULL,
            ref_id INT UNSIGNED NOT NULL DEFAULT 0,
            label VARCHAR(150) NOT NULL DEFAULT '',
            url VARCHAR(250) NOT NULL DEFAULT '',
            referrer VARCHAR(100) NOT NULL DEFAULT '',
            device VARCHAR(10) NOT NULL DEFAULT '',
            country CHAR(2) NOT NULL DEFAULT '',
            KEY idx_ts (ts),
            KEY idx_type_ts (type, ts),
            KEY idx_visitor (visitor, ts),
            KEY idx_country (country)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        // table without prefix created by a very early version
        if ($p !== '') { $GLOBALS['db']->query("DROP TABLE IF EXISTS CubeCart_vt_events"); }
    }

    /** Schema 1 -> 2: add the country column. */
    function vt_migrate($p)
    {
        if (!vt_q("SHOW COLUMNS FROM {$p}CubeCart_vt_events LIKE 'country'")) {
            $GLOBALS['db']->query("ALTER TABLE {$p}CubeCart_vt_events
                ADD COLUMN country CHAR(2) NOT NULL DEFAULT '' AFTER device, ADD KEY idx_country (country)");
        }
    }

    // ------------------------------------------------------------------ GeoIP
    function vt_geo_dir() { return dirname(__DIR__) . '/geoip'; }

    function vt_geo_file()
    {
        $f = glob(vt_geo_dir() . '/*.mmdb');
        return $f ? $f[0] : '';
    }

    /** If the user dropped a *.mmdb.gz in geoip/, unpack it once. */
    function vt_geo_prepare()
    {
        if (vt_geo_file() !== '' || !function_exists('gzopen')) { return; }
        $gz = glob(vt_geo_dir() . '/*.mmdb.gz');
        if (!$gz) { return; }
        $target = substr($gz[0], 0, -3);
        $in = @gzopen($gz[0], 'rb');
        $out = @fopen($target, 'wb');
        if ($in && $out) {
            while (!gzeof($in)) { fwrite($out, gzread($in, 1048576)); }
        }
        if ($in) { gzclose($in); }
        if ($out) { fclose($out); }
    }

    function vt_geo_status()
    {
        $f = vt_geo_file();
        $name = $f !== '' ? basename($f) : '';
        $attr = '';
        if ($name !== '') {
            if (preg_match('/dbip/i', $name)) { $attr = 'IP Geolocation by DB-IP (https://db-ip.com)'; }
            elseif (preg_match('/geo(lite|ip)/i', $name)) { $attr = 'This product includes GeoLite2 data created by MaxMind, available from https://www.maxmind.com'; }
        }
        return ['file' => $name, 'date' => $f !== '' ? date('Y-m-d', (int)filemtime($f)) : '', 'attribution' => $attr];
    }

    // ------------------------------------------------------------------ tracker queries
    function vt_tables($p)
    {
        return [
            'ev'  => $p . 'CubeCart_vt_events',
            'inv' => $p . 'CubeCart_inventory',
            'cat' => $p . 'CubeCart_category',
            'os'  => $p . 'CubeCart_order_summary',
            'oi'  => $p . 'CubeCart_order_inventory',
        ];
    }

    function vt_orders_ok($p)
    {
        $t = vt_tables($p);
        return vt_has_cols($t['os'], ['cart_order_id', 'status', 'order_date', 'total'])
            && vt_has_cols($t['oi'], ['cart_order_id', 'product_id', 'name', 'quantity', 'price']);
    }

    function vt_daily($p, $days)
    {
        $t = vt_tables($p);
        $out = [];
        for ($i = $days - 1; $i >= 0; $i--) { $out[date('Y-m-d', strtotime("-{$i} day"))] = ['v' => 0, 'p' => 0]; }
        foreach (vt_q("SELECT DATE(ts) d, COUNT(DISTINCT visitor) v, COUNT(*) p FROM {$t['ev']}
                       WHERE " . vt_since($days) . " AND type <> 'cart_add' GROUP BY DATE(ts)") as $r) {
            if (isset($out[$r['d']])) { $out[$r['d']] = ['v' => (int)$r['v'], 'p' => (int)$r['p']]; }
        }
        return $out;
    }

    function vt_hours($p, $days)
    {
        $t = vt_tables($p);
        $out = array_fill(0, 24, 0);
        foreach (vt_q("SELECT HOUR(ts) h, COUNT(*) c FROM {$t['ev']} WHERE " . vt_since($days) . " AND type <> 'cart_add' GROUP BY HOUR(ts)") as $r) {
            $out[(int)$r['h']] = (int)$r['c'];
        }
        return $out;
    }

    function vt_funnel($p, $days)
    {
        $t = vt_tables($p);
        $out = ['product' => 0, 'cart_add' => 0, 'checkout' => 0, 'complete' => 0];
        foreach (vt_q("SELECT type, COUNT(DISTINCT visitor) c FROM {$t['ev']}
                       WHERE " . vt_since($days) . " AND type IN ('product','cart_add','checkout','complete') GROUP BY type") as $r) {
            $out[$r['type']] = (int)$r['c'];
        }
        return $out;
    }

    function vt_totals($p, $days)
    {
        $t = vt_tables($p);
        $r = vt_q("SELECT COUNT(DISTINCT visitor) v, SUM(type <> 'cart_add') p FROM {$t['ev']} WHERE " . vt_since($days));
        return ['visitors' => (int)($r[0]['v'] ?? 0), 'pageviews' => (int)($r[0]['p'] ?? 0)];
    }

    function vt_live($p)
    {
        $t = vt_tables($p);
        $r = vt_q("SELECT COUNT(DISTINCT visitor) v FROM {$t['ev']} WHERE ts >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        return (int)($r[0]['v'] ?? 0);
    }

    /** kind: product | cart_add | category | search | referrer | device | page */
    function vt_top($p, $days, $kind, $limit)
    {
        $t = vt_tables($p);
        $s = vt_since($days, 'e');
        $l = (int)$limit;
        switch ($kind) {
            case 'product':
            case 'cart_add':
                $sql = "SELECT COALESCE(MAX(i.name), CONCAT('#', e.ref_id)) n, COUNT(*) c FROM {$t['ev']} e
                        LEFT JOIN {$t['inv']} i ON i.product_id = e.ref_id
                        WHERE {$s} AND e.type = '{$kind}' AND e.ref_id > 0 GROUP BY e.ref_id ORDER BY c DESC LIMIT {$l}";
                break;
            case 'category':
                $sql = "SELECT COALESCE(MAX(c.cat_name), CONCAT('#', e.ref_id)) n, COUNT(*) c FROM {$t['ev']} e
                        LEFT JOIN {$t['cat']} c ON c.cat_id = e.ref_id
                        WHERE {$s} AND e.type = 'category' AND e.ref_id > 0 GROUP BY e.ref_id ORDER BY c DESC LIMIT {$l}";
                break;
            case 'search':
                $sql = "SELECT label n, COUNT(*) c FROM {$t['ev']} e WHERE {$s} AND e.type = 'search' AND label <> '' GROUP BY label ORDER BY c DESC LIMIT {$l}";
                break;
            case 'referrer':
                $sql = "SELECT referrer n, COUNT(DISTINCT visitor) c FROM {$t['ev']} e WHERE {$s} AND referrer <> '' GROUP BY referrer ORDER BY c DESC LIMIT {$l}";
                break;
            case 'device':
                $sql = "SELECT device n, COUNT(DISTINCT visitor) c FROM {$t['ev']} e WHERE {$s} AND device <> '' GROUP BY device ORDER BY c DESC LIMIT {$l}";
                break;
            default:
                $sql = "SELECT url n, COUNT(*) c FROM {$t['ev']} e WHERE {$s} AND e.type <> 'cart_add' GROUP BY url ORDER BY c DESC LIMIT {$l}";
        }
        return vt_q($sql);
    }

    function vt_paths($p, $limit = 25)
    {
        $t = vt_tables($p);
        vt_q("SET SESSION group_concat_max_len = 16384");   // lange paden niet afkappen
        // naam bij een product of categorie (opgeslagen wordt alleen het nummer)
        $rows = vt_q("SELECT e.visitor, MIN(e.ts) first_seen, MAX(e.ts) last_seen, COUNT(*) n, MAX(e.device) device, MAX(e.country) country,
            GROUP_CONCAT(CONCAT_WS(': ', e.type, LEFT(COALESCE(NULLIF(e.label, ''), i.name, c.cat_name), 40)) ORDER BY e.ts SEPARATOR ' > ') path
            FROM {$t['ev']} e
            LEFT JOIN {$t['inv']} i ON e.type IN ('product', 'cart_add') AND i.product_id = e.ref_id
            LEFT JOIN {$t['cat']} c ON e.type = 'category' AND c.cat_id = e.ref_id
            WHERE e.ts >= DATE_SUB(NOW(), INTERVAL 2 DAY)
            GROUP BY e.visitor ORDER BY last_seen DESC LIMIT " . (int)$limit);
        foreach ($rows as &$r) {
            $r['path'] = function_exists('mb_substr') ? mb_substr((string)$r['path'], 0, 600) : substr((string)$r['path'], 0, 600);
        }
        unset($r);
        return $rows;
    }

    // ------------------------------------------------------------------ orders / revenue
    function vt_orders($p, $days)
    {
        $res = ['available' => false, 'n' => 0, 'revenue' => 0.0, 'aov' => 0.0, 'units' => 0, 'daily' => []];
        if (!vt_orders_ok($p)) { return $res; }
        $t = vt_tables($p);
        $res['available'] = true;
        $ok = 'status IN (2,3) AND ' . vt_order_since($days);
        $r = vt_q("SELECT COUNT(*) n, COALESCE(SUM(total),0) rev FROM {$t['os']} WHERE {$ok}");
        $res['n'] = (int)($r[0]['n'] ?? 0);
        $res['revenue'] = round((float)($r[0]['rev'] ?? 0), 2);
        $res['aov'] = $res['n'] ? round($res['revenue'] / $res['n'], 2) : 0.0;
        for ($i = $days - 1; $i >= 0; $i--) { $res['daily'][date('Y-m-d', strtotime("-{$i} day"))] = ['n' => 0, 'r' => 0.0]; }
        foreach (vt_q("SELECT DATE(FROM_UNIXTIME(order_date)) d, COUNT(*) n, COALESCE(SUM(total),0) r
                       FROM {$t['os']} WHERE {$ok} GROUP BY DATE(FROM_UNIXTIME(order_date))") as $x) {
            if (isset($res['daily'][$x['d']])) { $res['daily'][$x['d']] = ['n' => (int)$x['n'], 'r' => round((float)$x['r'], 2)]; }
        }
        $u = vt_q("SELECT COALESCE(SUM(oi.quantity),0) q FROM {$t['oi']} oi JOIN {$t['os']} os ON os.cart_order_id = oi.cart_order_id
                   WHERE os.status IN (2,3) AND " . vt_order_since($days, 'os'));
        $res['units'] = (int)($u[0]['q'] ?? 0);
        return $res;
    }

    /** Per product: views + added to cart (tracker) and units + revenue (shop orders). */
    function vt_products($p, $days, $limit)
    {
        $t = vt_tables($p);
        $rows = [];
        foreach (vt_q("SELECT e.ref_id id, COALESCE(MAX(i.name), CONCAT('#', e.ref_id)) n,
                              SUM(e.type = 'product') views, SUM(e.type = 'cart_add') carts
                       FROM {$t['ev']} e LEFT JOIN {$t['inv']} i ON i.product_id = e.ref_id
                       WHERE " . vt_since($days, 'e') . " AND e.type IN ('product','cart_add') AND e.ref_id > 0
                       GROUP BY e.ref_id") as $r) {
            $rows[(int)$r['id']] = ['id' => (int)$r['id'], 'name' => (string)$r['n'], 'views' => (int)$r['views'],
                                   'carts' => (int)$r['carts'], 'units' => 0, 'revenue' => 0.0];
        }
        if (vt_orders_ok($p)) {
            foreach (vt_q("SELECT oi.product_id id, MAX(oi.name) n, SUM(oi.quantity) qty, SUM(oi.price * oi.quantity) rev
                           FROM {$t['oi']} oi JOIN {$t['os']} os ON os.cart_order_id = oi.cart_order_id
                           WHERE os.status IN (2,3) AND " . vt_order_since($days, 'os') . " GROUP BY oi.product_id") as $r) {
                $id = (int)$r['id'];
                if (!isset($rows[$id])) {
                    $rows[$id] = ['id' => $id, 'name' => (string)$r['n'], 'views' => 0, 'carts' => 0, 'units' => 0, 'revenue' => 0.0];
                }
                $rows[$id]['units'] = (int)$r['qty'];
                $rows[$id]['revenue'] = round((float)$r['rev'], 2);
            }
        }
        $rows = array_values($rows);
        usort($rows, function ($a, $b) {
            return [$b['revenue'], $b['views']] <=> [$a['revenue'], $a['views']];
        });
        return array_slice($rows, 0, (int)$limit);
    }

    // ------------------------------------------------------------------ countries
    function vt_countries($p, $days, $limit)
    {
        $t = vt_tables($p);
        $rows = vt_q("SELECT country c, COUNT(DISTINCT visitor) v, SUM(type <> 'cart_add') p,
                             COUNT(DISTINCT CASE WHEN type = 'complete' THEN visitor END) b
                      FROM {$t['ev']} WHERE " . vt_since($days) . " AND country <> ''
                      GROUP BY country ORDER BY v DESC, p DESC LIMIT " . (int)$limit);
        $unk = vt_q("SELECT COUNT(DISTINCT visitor) v FROM {$t['ev']} WHERE " . vt_since($days) . " AND country = ''");
        return ['rows' => $rows, 'unknown' => (int)($unk[0]['v'] ?? 0)];
    }

    // ------------------------------------------------------------------ abandoned carts
    /**
     * A visitor (one anonymous id per day) is "abandoned" when they added something to the cart
     * (or reached checkout) but did not reach the order-complete page the same day.
     */
    function vt_carts($p, $days, $limit)
    {
        $t = vt_tables($p);
        $join = "LEFT JOIN {$t['ev']} c ON c.visitor = a.visitor AND c.type = 'complete'";
        $res = ['daily' => [], 'carts' => 0, 'abandoned' => 0, 'checkout' => 0, 'checkout_abandoned' => 0, 'products' => [], 'pending' => ['n' => 0, 'total' => 0.0, 'rows' => [], 'available' => false]];

        for ($i = $days - 1; $i >= 0; $i--) { $res['daily'][date('Y-m-d', strtotime("-{$i} day"))] = ['carts' => 0, 'abandoned' => 0]; }
        foreach (vt_q("SELECT DATE(a.ts) d, COUNT(DISTINCT a.visitor) carts,
                              COUNT(DISTINCT CASE WHEN c.id IS NULL THEN a.visitor END) abandoned
                       FROM {$t['ev']} a {$join} WHERE a.type = 'cart_add' AND " . vt_since($days, 'a') . " GROUP BY DATE(a.ts)") as $r) {
            if (isset($res['daily'][$r['d']])) { $res['daily'][$r['d']] = ['carts' => (int)$r['carts'], 'abandoned' => (int)$r['abandoned']]; }
            $res['carts'] += (int)$r['carts'];
            $res['abandoned'] += (int)$r['abandoned'];
        }
        $r = vt_q("SELECT COUNT(DISTINCT a.visitor) reached, COUNT(DISTINCT CASE WHEN c.id IS NULL THEN a.visitor END) abandoned
                   FROM {$t['ev']} a {$join} WHERE a.type = 'checkout' AND " . vt_since($days, 'a'));
        $res['checkout'] = (int)($r[0]['reached'] ?? 0);
        $res['checkout_abandoned'] = (int)($r[0]['abandoned'] ?? 0);

        foreach (vt_q("SELECT a.ref_id id, COALESCE(MAX(i.name), CONCAT('#', a.ref_id)) n,
                              COUNT(DISTINCT a.visitor) carts, COUNT(DISTINCT CASE WHEN c.id IS NULL THEN a.visitor END) abandoned
                       FROM {$t['ev']} a {$join} LEFT JOIN {$t['inv']} i ON i.product_id = a.ref_id
                       WHERE a.type = 'cart_add' AND a.ref_id > 0 AND " . vt_since($days, 'a') . "
                       GROUP BY a.ref_id ORDER BY abandoned DESC, carts DESC LIMIT " . (int)$limit) as $x) {
            $res['products'][] = ['id' => (int)$x['id'], 'name' => (string)$x['n'], 'carts' => (int)$x['carts'], 'abandoned' => (int)$x['abandoned']];
        }

        // unpaid shop orders (status 1 = pending) older than one hour
        if (vt_orders_ok($p)) {
            $res['pending']['available'] = true;
            $rows = vt_q("SELECT cart_order_id id, order_date d, total FROM {$t['os']}
                          WHERE status = 1 AND " . vt_order_since($days) . " AND order_date <= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 HOUR))
                          ORDER BY order_date DESC LIMIT 500");
            foreach ($rows as $x) { $res['pending']['n']++; $res['pending']['total'] += (float)$x['total']; }
            $res['pending']['total'] = round($res['pending']['total'], 2);
            foreach (array_slice($rows, 0, 15) as $x) {
                $res['pending']['rows'][] = ['id' => (string)$x['id'], 'date' => date('Y-m-d H:i', (int)$x['d']), 'total' => round((float)$x['total'], 2)];
            }
        }
        return $res;
    }

    // ------------------------------------------------------------------ CSV export
    /** Returns [header[], rows[][]] or null for an unknown export. */
    function vt_export_rows($name, $p, $days)
    {
        $t = vt_tables($p);
        switch ($name) {
            case 'dagen':
                $d = vt_daily($p, $days);
                $o = vt_orders($p, $days);
                $rows = [];
                foreach ($d as $day => $v) {
                    $rows[] = [$day, $v['v'], $v['p'], $o['daily'][$day]['n'] ?? 0, $o['daily'][$day]['r'] ?? 0];
                }
                return [['datum', 'bezoekers', 'paginaweergaven', 'bestellingen', 'omzet'], $rows];
            case 'producten':
                $rows = [];
                foreach (vt_products($p, $days, 5000) as $r) {
                    $rows[] = [$r['id'], $r['name'], $r['views'], $r['carts'], $r['units'], $r['revenue'],
                               $r['views'] ? round($r['units'] / $r['views'] * 100, 2) : 0];
                }
                return [['product_id', 'product', 'bekeken', 'in_winkelwagen', 'verkocht', 'omzet_excl_btw', 'verkocht_per_100_weergaven'], $rows];
            case 'landen':
                $c = vt_countries($p, $days, 500);
                $rows = [];
                foreach ($c['rows'] as $r) { $rows[] = [$r['c'], $r['v'], $r['p'], $r['b']]; }
                return [['land', 'bezoekers', 'paginaweergaven', 'kopers'], $rows];
            case 'winkelwagens':
                $c = vt_carts($p, $days, 5000);
                $rows = [];
                foreach ($c['products'] as $r) {
                    $rows[] = [$r['id'], $r['name'], $r['carts'], $r['abandoned'], $r['carts'] ? round($r['abandoned'] / $r['carts'] * 100, 1) : 0];
                }
                return [['product_id', 'product', 'winkelwagens', 'verlaten', 'verlaten_pct'], $rows];
            case 'zoektermen':
                $rows = [];
                foreach (vt_top($p, $days, 'search', 5000) as $r) { $rows[] = [$r['n'], $r['c']]; }
                return [['zoekterm', 'aantal'], $rows];
            case 'herkomst':
                $rows = [];
                foreach (vt_top($p, $days, 'referrer', 5000) as $r) { $rows[] = [$r['n'], $r['c']]; }
                return [['verwijzer', 'bezoekers'], $rows];
            case 'events':
                $rows = [];
                foreach (vt_q("SELECT e.ts, e.visitor, e.type, e.ref_id, COALESCE(NULLIF(e.label, ''), i.name, c.cat_name, '') naam,
                                      e.url, e.referrer, e.device, e.country
                               FROM {$t['ev']} e
                               LEFT JOIN {$t['inv']} i ON e.type IN ('product', 'cart_add') AND i.product_id = e.ref_id
                               LEFT JOIN {$t['cat']} c ON e.type = 'category' AND c.cat_id = e.ref_id
                               WHERE " . vt_since($days, 'e') . " ORDER BY e.ts DESC LIMIT 50000") as $r) {
                    $rows[] = [$r['ts'], $r['visitor'], $r['type'], $r['ref_id'], $r['naam'], $r['url'], $r['referrer'], $r['device'], $r['country']];
                }
                return [['tijd', 'bezoeker_hash', 'type', 'ref_id', 'naam_of_zoekterm', 'url', 'verwijzer', 'apparaat', 'land'], $rows];
        }
        return null;
    }

    /** Neutralise spreadsheet formulas (search terms are user input). */
    function vt_csv_cell($v)
    {
        if (is_string($v) && $v !== '' && strpos("=+-@\t\r", $v[0]) !== false) { return "'" . $v; }
        return $v;
    }

    /** Write CSV text. $nl = true: ';' separator and decimal comma (Dutch Excel). */
    function vt_csv($header, $rows, $nl)
    {
        $out = fopen('php://temp', 'r+');
        $delim = $nl ? ';' : ',';
        fputcsv($out, $header, $delim, '"', '');
        foreach ($rows as $row) {
            $line = [];
            foreach ($row as $v) {
                if (is_float($v)) { $v = $nl ? number_format($v, 2, ',', '') : number_format($v, 2, '.', ''); }
                $line[] = vt_csv_cell($v);
            }
            fputcsv($out, $line, $delim, '"', '');
        }
        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);
        return "\xEF\xBB\xBF" . $csv;
    }
}
