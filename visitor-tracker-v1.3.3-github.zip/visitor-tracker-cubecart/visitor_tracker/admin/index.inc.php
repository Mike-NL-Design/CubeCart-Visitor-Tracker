<?php
/**
 * Visitor Tracker - admin controller: install/migrate, CSV export, dashboard data.
 *
 * @copyright 2026 MikeNL
 * @license   MIT (see LICENSE)
 * SPDX-License-Identifier: MIT
 */
if (!defined('CC_INI_SET')) { die('Access Denied'); }
Admin::getInstance()->permissions('settings', CC_PERM_EDIT, true);

// Bij een fout tonen we een korte melding (alleen zichtbaar voor beheerders)
$vt_show = function ($t, $m, $f, $l) {
    echo '<pre style="background:#fee;border:1px solid #c00;padding:10px;margin:10px;white-space:pre-wrap">Visitor Tracker fout: '
       . htmlspecialchars($t . ': ' . $m . ' (' . basename($f) . ':' . $l . ')') . '</pre>';
};
try {
    require_once __DIR__ . '/vt_data.inc.php';

    $vt_flag = dirname(__DIR__) . '/.installed2';
    $vt_schema_now = 2;

    // ---- Installatie / migratie ---------------------------------------------
    $flag = vt_read_flag($vt_flag);
    if ($flag === null) {
        $p = vt_detect_prefix();
        vt_create_table($p);
        vt_write_flag($vt_flag, $p, $vt_schema_now);
    } else {
        $p = $flag['p'];
        if ($flag['schema'] < $vt_schema_now) {
            vt_migrate($p);
            vt_write_flag($vt_flag, $p, $vt_schema_now);
        }
    }
    vt_geo_prepare();

    $days = isset($_GET['days']) ? max(1, min(365, (int)$_GET['days'])) : 30;

    // ---- CSV-export (verlaat het script direct na het schrijven) -----------------
    if (isset($_GET['export'])) {
        $ex = vt_export_rows((string)$_GET['export'], $p, $days);
        if ($ex !== null) {
            $nl  = !isset($_GET['fmt']) || $_GET['fmt'] !== 'en';
            $csv = vt_csv($ex[0], $ex[1], $nl);
            while (ob_get_level() > 0) { @ob_end_clean(); }
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="visitor-tracker-' . preg_replace('/[^a-z]/', '', (string)$_GET['export']) . '-' . date('Y-m-d') . '.csv"');
            header('Cache-Control: no-store');
            header('Content-Length: ' . strlen($csv));
            echo $csv;
            exit;
        }
    }

    // ---- Dashboard-data ----------------------------------------------------------
    $tot = vt_totals($p, $days);
    $cur = $GLOBALS['config']->get('config', 'default_currency');
    $payload = [
        'days' => $days, 'currency' => (is_string($cur) && preg_match('/^[A-Z]{3}$/', $cur)) ? $cur : 'EUR',
        'visitors' => $tot['visitors'], 'pageviews' => $tot['pageviews'], 'live' => vt_live($p),
        'daily' => vt_daily($p, $days), 'hours' => vt_hours($p, $days), 'funnel' => vt_funnel($p, $days),
        'topProducts' => vt_top($p, $days, 'product', 10), 'topCarted' => vt_top($p, $days, 'cart_add', 10),
        'topCats' => vt_top($p, $days, 'category', 10), 'topSearch' => vt_top($p, $days, 'search', 10),
        'topRef' => vt_top($p, $days, 'referrer', 10), 'devices' => vt_top($p, $days, 'device', 10),
        'paths' => vt_paths($p, 25),
        'orders' => vt_orders($p, $days), 'products' => vt_products($p, $days, 25),
        'countries' => vt_countries($p, $days, 25), 'geo' => vt_geo_status(),
        'carts' => vt_carts($p, $days, 25),
    ];
    $GLOBALS['smarty']->assign('VT_PAYLOAD', base64_encode(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR)));
    $GLOBALS['smarty']->assign('VT_CHARTJS', CC_ROOT_REL . 'modules/plugins/visitor_tracker/skin/admin/chart.umd.js');
    $GLOBALS['smarty']->assign('VT_BASE', '?_g=plugins&type=plugins&module=visitor_tracker');
    $GLOBALS['smarty']->assign('VT_DAYS', $days);

    $GLOBALS['main']->addTabControl('Dashboard', 'vt_dashboard');
    $GLOBALS['main']->addTabControl('Instellingen', 'general');

    $module = new Module(__FILE__, $GLOBALS['_GET']['module'], 'admin/vt_overview.tpl', true, true);
    $page_content = $module->display();
} catch (Throwable $e) {
    $vt_show(get_class($e), $e->getMessage(), $e->getFile(), $e->getLine());
    if (!isset($page_content)) { $page_content = ''; }
}
