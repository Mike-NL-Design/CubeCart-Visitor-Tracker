<?php
/**
 * Visitor Tracker - frontend tracking.
 * Draait bij elke frontend-pageload. Slaat GEEN IP-adres of cookie op:
 * bezoeker-ID = dagelijks wisselende hash (privacyvriendelijk).
 *
 * @copyright 2026 MikeNL
 * @license   MIT (see LICENSE)
 * SPDX-License-Identifier: MIT
 */
if (!defined('CC_INI_SET')) { die('Access Denied'); }

(function () {
    $vt_flag = dirname(__DIR__) . '/.installed2';
    if (!file_exists($vt_flag)) { return; }
    $vt_parts  = explode('|', trim((string)@file_get_contents($vt_flag)));
    $vt_prefix = preg_replace('/[^A-Za-z0-9_]/', '', $vt_parts[0]);
    $vt_schema = (int)($vt_parts[1] ?? 1);   // 2 = kolom 'country' aanwezig
    if (defined('CC_IN_ADMIN') && CC_IN_ADMIN) { return; }

    try {
        $cut = function ($s, $a, $n) { return function_exists('mb_substr') ? mb_substr($s, $a, $n) : substr($s, $a, $n); };
        $low = function ($s) { return function_exists('mb_strtolower') ? mb_strtolower($s) : strtolower($s); };

        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if (!in_array($method, ['GET', 'POST'], true)) { return; }
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) { return; }

        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ($ua === '' || preg_match('/bot|crawl|spider|slurp|bing|facebookexternalhit|preview|monitor|curl|wget|python|java|headless|lighthouse|pingdom|uptime|semrush|ahrefs|mj12|dotbot|nexus 5x|scrapy|httpclient/i', $ua)) { return; }

        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        if (preg_match('/\.(css|js|map|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|xml|txt|json)$/i', $path)) { return; }

        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $settings = $GLOBALS['config']->get('visitor_tracker');
        if (!empty($settings['exclude_ips'])) {
            $list = preg_split('/[\s,;]+/', (string)$settings['exclude_ips'], -1, PREG_SPLIT_NO_EMPTY);
            if (in_array($ip, $list, true)) { return; }
        }

        // Anonieme, dagelijks roterende bezoeker-hash (geen cookie, geen IP opgeslagen)
        $visitor = substr(hash('sha256', $ip . '|' . $ua . '|' . date('Y-m-d') . '|' . CC_ROOT_DIR), 0, 16);

        $a = isset($_GET['_a']) ? (string)$_GET['_a'] : '';
        $type = 'other'; $ref = 0; $label = '';

        if ($a === '' || $a === 'index' || $a === 'home') {
            $type = 'home';
        } elseif ($a === 'product') {
            $type = 'product'; $ref = (int)($_GET['product_id'] ?? 0);
        } elseif ($a === 'category') {
            if (isset($_GET['search']) && is_array($_GET['search']) && !empty($_GET['search']['keywords'])) {
                $type = 'search'; $label = $low(trim((string)$_GET['search']['keywords']));
            } else {
                $type = 'category'; $ref = (int)($_GET['cat_id'] ?? 0);
            }
        } elseif ($a === 'basket') {
            $type = 'basket';
        } elseif ($a === 'cart' || $a === 'checkout' || $a === 'confirm' || $a === 'gateway') {
            $type = 'checkout';
        } elseif ($a === 'complete') {
            $type = 'complete';
        } elseif ($a === 'document') {
            $type = 'document'; $ref = (int)($_GET['doc_id'] ?? 0);
        } elseif ($a === 'search') {
            $type = 'search'; $label = $low(trim((string)($_GET['search']['keywords'] ?? '')));
        } else {
            $label = $cut($a, 0, 40);   // welke pagina het was (bv. register, login)
        }

        $host = strtolower(parse_url($_SERVER['HTTP_REFERER'] ?? '', PHP_URL_HOST) ?: '');
        $own  = strtolower($_SERVER['HTTP_HOST'] ?? '');
        if ($host === '' || $host === $own || $host === 'www.' . $own || 'www.' . $host === $own) { $host = ''; }

        $device = 'desktop';
        if (preg_match('/ipad|tablet/i', $ua)) { $device = 'tablet'; }
        elseif (preg_match('/mobi|android|iphone/i', $ua)) { $device = 'mobile'; }

        // Land (alleen de 2-letter code wordt opgeslagen, nooit het IP-adres)
        $country = '';
        if ($vt_schema >= 2) {
            foreach (['HTTP_CF_IPCOUNTRY', 'HTTP_CLOUDFRONT_VIEWER_COUNTRY', 'GEOIP_COUNTRY_CODE'] as $k) {
                $c = strtoupper((string)($_SERVER[$k] ?? ''));
                if (preg_match('/^[A-Z]{2}$/', $c) && !in_array($c, ['XX', 'T1', 'ZZ'], true)) { $country = $c; break; }
            }
            if ($country === '') {
              try {
                $mm = glob(dirname(__DIR__) . '/geoip/*.mmdb');
                if ($mm) {
                    if (!class_exists('MaxMind\\Db\\Reader', false)) {
                        $base = dirname(__DIR__) . '/lib/MaxMind/Db/';
                        foreach (['Reader/InvalidDatabaseException', 'Reader/UnsupportedPlatformException', 'Reader/Util', 'Reader/Metadata', 'Reader/Decoder', 'Reader'] as $f) {
                            require_once $base . $f . '.php';
                        }
                    }
                    $geoIp = function_exists('get_ip_address') ? get_ip_address() : $ip;
                    if (filter_var($geoIp, FILTER_VALIDATE_IP)) {
                        $reader = new \MaxMind\Db\Reader($mm[0]);
                        $rec = $reader->get($geoIp);
                        $reader->close();
                        if (is_array($rec)) {
                            $c = strtoupper((string)($rec['country']['iso_code'] ?? ($rec['registered_country']['iso_code'] ?? '')));
                            if (preg_match('/^[A-Z]{2}$/', $c)) { $country = $c; }
                        }
                    }
                }
              } catch (Throwable $ge) { /* land onbekend: tracking gaat gewoon door */ }
            }
        }

        $row = [
            'ts'       => date('Y-m-d H:i:s'),
            'visitor'  => $visitor,
            'type'     => $type,
            'ref_id'   => $ref,
            'label'    => $cut($label, 0, 150),
            'url'      => $cut($path, 0, 250),
            'referrer' => $cut($host, 0, 100),
            'device'   => $device,
        ];
        if ($vt_schema >= 2) { $row['country'] = $country; }
        $db = $GLOBALS['db'];
        $db->insert('CubeCart_vt_events', $row);

        // Toevoegen aan winkelwagen (intentie) als apart event
        if (isset($_REQUEST['add'])) {
            $add = $_REQUEST['add'];
            $pid = is_array($add) ? (int)reset($add) : (int)$add;
            if ($pid > 0) {
                $cartRow = [
                    'ts' => date('Y-m-d H:i:s'), 'visitor' => $visitor, 'type' => 'cart_add',
                    'ref_id' => $pid, 'label' => '', 'url' => $cut($path, 0, 250),
                    'referrer' => '', 'device' => $device,
                ];
                if ($vt_schema >= 2) { $cartRow['country'] = $country; }
                $db->insert('CubeCart_vt_events', $cartRow);
            }
        }

        // Af en toe oude data opruimen
        if (mt_rand(1, 300) === 1) {
            $days = max(7, (int)($settings['retention_days'] ?? 90));
            $db->query("DELETE FROM {$vt_prefix}CubeCart_vt_events WHERE ts < DATE_SUB(NOW(), INTERVAL " . $days . " DAY)");
        }
    } catch (Throwable $e) {
        // Tracking mag de shop nooit laten haperen
    }
})();
