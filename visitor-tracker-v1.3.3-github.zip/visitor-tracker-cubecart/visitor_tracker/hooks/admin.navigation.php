<?php
/**
 * Visitor Tracker - menu-item "Bezoekers" in de groep "Rapportage".
 *
 * @copyright 2026 MikeNL
 * @license   MIT (see LICENSE)
 * SPDX-License-Identifier: MIT
 */
if (!defined('CC_INI_SET')) { die('Access Denied'); }

(function () {
    $main = $GLOBALS['main'] ?? null;
    if (!is_object($main) || !method_exists($main, 'addNavItem')) { return; }

    $group = 'Rapportage';
    try {
        $rp = new ReflectionProperty($main, '_navigation');
        $rp->setAccessible(true);
        $nav = $rp->getValue($main);
        if (is_array($nav)) {
            $found = false;
            foreach (array_keys($nav) as $g) {
                if (strcasecmp(trim((string)$g), 'Rapportage') === 0) { $group = $g; $found = true; break; }
            }
            if (!$found) {
                foreach (array_keys($nav) as $g) {
                    if (preg_match('/rapport|report|statist/i', (string)$g)) { $group = $g; break; }
                }
            }
        }
    } catch (Throwable $e) { /* standaardgroep gebruiken */ }

    $main->addNavItem($group, ['Bezoekers' => '?_g=plugins&type=plugins&module=visitor_tracker']);
})();
