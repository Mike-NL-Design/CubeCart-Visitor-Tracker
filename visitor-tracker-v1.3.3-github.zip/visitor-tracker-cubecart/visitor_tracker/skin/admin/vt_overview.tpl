<form action="{$VAL_SELF}" method="post" enctype="multipart/form-data">

<div id="vt_dashboard" class="tab_content">
  <h3>Visitor Tracker</h3>
  <div id="vt-root" data-payload="{$VT_PAYLOAD}" data-base="{$VT_BASE}">
    <div class="vt-bar">
      <span>Periode:</span>
      <a class="vt-period" data-days="1" href="{$VT_BASE}&days=1">Vandaag</a>
      <a class="vt-period" data-days="7" href="{$VT_BASE}&days=7">7 dagen</a>
      <a class="vt-period" data-days="30" href="{$VT_BASE}&days=30">30 dagen</a>
      <a class="vt-period" data-days="90" href="{$VT_BASE}&days=90">90 dagen</a>
      <span class="vt-live"><i></i> <b id="vt-live">0</b> nu actief</span>
    </div>

    <div class="vt-nav" id="vt-nav">
      <button type="button" data-pane="overview">Overzicht</button>
      <button type="button" data-pane="products">Producten &amp; omzet</button>
      <button type="button" data-pane="countries">Landen</button>
      <button type="button" data-pane="carts">Winkelwagens</button>
      <button type="button" data-pane="export">Export</button>
    </div>

    <div class="vt-pane" id="vt-p-overview">
      <div class="vt-tiles" id="vt-tiles"></div>
      <div class="vt-grid">
        <div class="vt-card vt-wide"><h4>Bezoekers &amp; paginaweergaven per dag</h4><div class="vt-h"><canvas id="c-daily"></canvas></div></div>
        <div class="vt-card"><h4>Trechter (unieke bezoekers)</h4><div class="vt-h"><canvas id="c-funnel"></canvas></div></div>
        <div class="vt-card"><h4>Drukste uren</h4><div class="vt-h"><canvas id="c-hours"></canvas></div></div>
        <div class="vt-card"><h4>Meest bekeken producten</h4><div class="vt-h"><canvas id="c-products"></canvas></div></div>
        <div class="vt-card"><h4>Meest in winkelwagen gelegd</h4><div class="vt-h"><canvas id="c-carted"></canvas></div></div>
        <div class="vt-card"><h4>Populaire categorieen</h4><div class="vt-h"><canvas id="c-cats"></canvas></div></div>
        <div class="vt-card"><h4>Zoektermen</h4><div class="vt-h"><canvas id="c-search"></canvas></div></div>
        <div class="vt-card"><h4>Herkomst (verwijzers)</h4><div class="vt-h"><canvas id="c-ref"></canvas></div></div>
        <div class="vt-card"><h4>Apparaten</h4><div class="vt-h"><canvas id="c-dev"></canvas></div></div>
        <div class="vt-card vt-wide"><h4>Klikpad per bezoeker (laatste 2 dagen)</h4>
          <div class="vt-scroll"><table class="vt-table" id="vt-paths"><thead><tr><th>Laatst gezien</th><th>Land</th><th>Apparaat</th><th>Acties</th><th>Pad</th></tr></thead><tbody></tbody></table></div>
        </div>
      </div>
    </div>

    <div class="vt-pane" id="vt-p-products" style="display:none">
      <div class="vt-note vt-warn" id="vt-noorders" style="display:none">De bestelgegevens van CubeCart zijn niet gevonden (tabel of kolommen ontbreken), dus omzet is niet beschikbaar. Weergaven en winkelwagens worden wel getoond.</div>
      <div class="vt-tiles" id="vt-tiles2"></div>
      <div class="vt-grid">
        <div class="vt-card vt-wide"><h4>Omzet per dag</h4><div class="vt-h"><canvas id="c-revday"></canvas></div></div>
        <div class="vt-card vt-wide"><h4>Top 10 producten naar omzet</h4><div class="vt-h"><canvas id="c-toprev"></canvas></div></div>
        <div class="vt-card vt-wide"><h4>Producten: bekeken, winkelwagen, verkocht en omzet</h4>
          <div class="vt-scroll"><table class="vt-table" id="vt-prodtable"><thead><tr><th>Product</th><th class="n">Bekeken</th><th class="n">In winkelwagen</th><th class="n">Verkocht</th><th class="n">Omzet excl. btw</th><th class="n">Verkocht per 100x bekeken</th></tr></thead><tbody></tbody></table></div>
          <p class="vt-note">Omzet = prijs &times; aantal uit betaalde bestellingen (status Processing of Complete), zonder btw, verzendkosten en kortingen. Gebruik de export voor alle producten.</p>
        </div>
      </div>
    </div>

    <div class="vt-pane" id="vt-p-countries" style="display:none">
      <div class="vt-note" id="vt-geoinfo"></div>
      <div class="vt-grid">
        <div class="vt-card vt-wide"><h4>Bezoekers per land</h4><div class="vt-h vt-tall"><canvas id="c-country"></canvas></div></div>
        <div class="vt-card vt-wide"><h4>Landen</h4>
          <div class="vt-scroll"><table class="vt-table" id="vt-ctable"><thead><tr><th>Land</th><th class="n">Bezoekers</th><th class="n">Paginaweergaven</th><th class="n">Kopers</th></tr></thead><tbody></tbody></table></div>
        </div>
      </div>
    </div>

    <div class="vt-pane" id="vt-p-carts" style="display:none">
      <div class="vt-tiles" id="vt-tiles3"></div>
      <div class="vt-grid">
        <div class="vt-card vt-wide"><h4>Winkelwagens per dag: gestart en verlaten</h4><div class="vt-h"><canvas id="c-cartsday"></canvas></div></div>
        <div class="vt-card"><h4>Producten in verlaten winkelwagens</h4>
          <div class="vt-scroll"><table class="vt-table" id="vt-cartprod"><thead><tr><th>Product</th><th class="n">Winkelwagens</th><th class="n">Verlaten</th></tr></thead><tbody></tbody></table></div>
        </div>
        <div class="vt-card"><h4>Onbetaalde bestellingen (ouder dan 1 uur)</h4>
          <div class="vt-scroll"><table class="vt-table" id="vt-pending"><thead><tr><th>Bestelling</th><th>Datum</th><th class="n">Totaal</th></tr></thead><tbody></tbody></table></div>
          <p class="vt-note" id="vt-pendnote"></p>
        </div>
      </div>
      <p class="vt-note">Een bezoeker telt als "verlaten" als hij iets in de winkelwagen legde maar dezelfde dag niet op de bestelling-voltooid-pagina kwam. Omdat de bezoeker-ID elke dag wisselt, kan iemand die na middernacht afrekent als verlaten tellen. Onbetaalde bestellingen komen uit CubeCart zelf (status Pending); daarbij zitten ook bestellingen die nog op een bankoverschrijving wachten.</p>
    </div>

    <div class="vt-pane" id="vt-p-export" style="display:none">
      <div class="vt-card">
        <h4>CSV-export voor de gekozen periode</h4>
        <p class="vt-note">Excel (NL): scheidingsteken <code>;</code> en decimale komma. Standaard: komma en decimale punt.</p>
        <table class="vt-table" id="vt-exports"><tbody></tbody></table>
      </div>
    </div>

    <p class="vt-note" id="vt-attr"></p>
  </div>
</div>

<div id="general" class="tab_content">
  <h3>Instellingen</h3>
  <fieldset>
    <div><label for="status">Status</label>
      <span><input type="hidden" name="module[status]" id="status" class="toggle" value="{$MODULE.status}"></span></div>
    <div><label for="vt_ret">Bewaartermijn (dagen)</label>
      <span><input type="text" name="module[retention_days]" id="vt_ret" class="textbox number" value="{if $MODULE.retention_days}{$MODULE.retention_days}{else}90{/if}"></span></div>
    <div><label for="vt_ex">IP-adressen uitsluiten</label>
      <span><input type="text" name="module[exclude_ips]" id="vt_ex" class="textbox" value="{$MODULE.exclude_ips}"> <small>kommagescheiden, bv. je eigen IP</small></span></div>
  </fieldset>
  <p><small>Er worden geen IP-adressen of cookies opgeslagen: een bezoeker is een anonieme hash die elke dag wisselt. Voor landen zie <code>geoip/README.txt</code> in de pluginmap.</small></p>
</div>

<div class="form_control">
  <input type="submit" value="{$LANG.common.save}">
</div>
<input type="hidden" name="token" value="{$SESSION_TOKEN}">
</form>

<style>
{literal}
#vt-root{font-size:13px}
.vt-bar{display:flex;gap:10px;align-items:center;margin:8px 0 10px;flex-wrap:wrap}
.vt-bar a{padding:4px 10px;border:1px solid #c8ccd0;border-radius:14px;text-decoration:none;color:#333;background:#fff}
.vt-bar a:hover,.vt-bar a.on{background:#e3eefb;border-color:#6aa0e0}
.vt-live{margin-left:auto;font-weight:600}
.vt-live i{display:inline-block;width:9px;height:9px;border-radius:50%;background:#2fb344;margin-right:4px;animation:vtp 1.6s infinite}
@keyframes vtp{50%{opacity:.25}}
.vt-nav{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px;border-bottom:1px solid #dfe3e7;padding-bottom:8px}
.vt-nav button{padding:6px 14px;border:1px solid #c8ccd0;border-radius:6px;background:#fff;color:#333;cursor:pointer;font-size:13px}
.vt-nav button:hover{background:#eef3f8}
.vt-nav button.on{background:#3b82f6;border-color:#3b82f6;color:#fff}
.vt-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:14px}
.vt-tile{background:#fff;border:1px solid #dfe3e7;border-radius:8px;padding:12px 14px}
.vt-tile b{display:block;font-size:22px;margin-top:2px}
.vt-tile span{color:#6b7580}
.vt-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.vt-card{background:#fff;border:1px solid #dfe3e7;border-radius:8px;padding:12px 14px;min-width:0}
.vt-card h4{margin:0 0 8px;font-size:13px;color:#333}
.vt-wide{grid-column:1/-1}
.vt-h{position:relative;height:250px}
.vt-tall{height:420px}
.vt-scroll{overflow-x:auto}
.vt-table{width:100%;border-collapse:collapse}
.vt-table th,.vt-table td{padding:6px 8px;border-bottom:1px solid #eceff2;text-align:left;vertical-align:top}
.vt-table .n,.vt-table td.n{text-align:right;white-space:nowrap}
.vt-table td:last-child{word-break:break-word}
.vt-note{color:#6b7580;margin:8px 0}
.vt-warn{background:#fff7e0;border:1px solid #f0d27a;border-radius:6px;padding:8px 10px;color:#6b5200}
.vt-btn{display:inline-block;padding:4px 10px;border:1px solid #c8ccd0;border-radius:5px;text-decoration:none;color:#333;background:#fff;margin-right:6px}
.vt-btn:hover{background:#e3eefb}
@media(max-width:900px){.vt-grid{grid-template-columns:1fr}}
{/literal}
</style>
<script src="{$VT_CHARTJS}"></script>
<script>
{literal}
(function(){
  var root=document.getElementById('vt-root'); if(!root||typeof Chart==='undefined')return;
  var d;
  try{ d=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(root.getAttribute('data-payload')),function(c){return c.charCodeAt(0)}))); }catch(e){ return; }
  var BASE=root.getAttribute('data-base');
  var C=['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#64748b'];
  var nf=function(n){return Number(n).toLocaleString('nl-NL')};
  var money=function(n){try{return new Intl.NumberFormat('nl-NL',{style:'currency',currency:d.currency||'EUR'}).format(n)}catch(e){return Number(n).toFixed(2)}};
  var pct=function(a,b){return b?(a/b*100).toFixed(1).replace('.',',')+'%':'0%'};
  var regionNames=null; try{regionNames=new Intl.DisplayNames(['nl'],{type:'region'});}catch(e){}
  var cname=function(c){try{return (regionNames&&regionNames.of(c))||c}catch(e){return c}};
  var base={responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}};
  var byId=function(i){return document.getElementById(i)};
  function mk(id,cfg){var el=byId(id); if(el) new Chart(el,cfg);}
  function short(s,n){s=String(s);return s.length>n?s.slice(0,n-2)+'..':s}
  function empty(id){var el=byId(id); if(!el||!el.parentNode)return; var box=el.parentNode; box.style.height='auto'; box.innerHTML='<p class="vt-note">Geen gegevens in deze periode.</p>';}
  function hbar(id,rows,color,fmt){
    if(!rows.length){empty(id);return;}
    mk(id,{type:'bar',data:{labels:rows.map(function(r){return short(r.n,38)}),datasets:[{data:rows.map(function(r){return +r.c}),backgroundColor:color}]},
      options:Object.assign({},base,{indexAxis:'y',scales:{x:{beginAtZero:true,ticks:{precision:0,callback:fmt||undefined}}}})});
  }
  function tiles(id,list){byId(id).innerHTML=list.map(function(t){return '<div class="vt-tile"><span>'+t[0]+'</span><b>'+t[1]+'</b></div>'}).join('')}
  function rowsInto(tableId,rows,numCols){
    var tb=document.querySelector('#'+tableId+' tbody'); tb.innerHTML='';
    if(!rows.length){var tr=document.createElement('tr');var td=document.createElement('td');td.colSpan=10;td.textContent='Geen gegevens in deze periode.';tr.appendChild(td);tb.appendChild(tr);return;}
    rows.forEach(function(r){var tr=document.createElement('tr');
      r.forEach(function(v,i){var td=document.createElement('td');td.textContent=v;if(numCols&&numCols.indexOf(i)>-1)td.className='n';tr.appendChild(td)});
      tb.appendChild(tr)});
  }
  document.getElementById('vt-live').textContent=d.live;

  var f=d.funnel, o=d.orders, cr=d.carts;
  var days=Object.keys(d.daily);
  var dayLbl=function(x){return x.slice(8)+'-'+x.slice(5,7)};

  var panes={
    overview:function(){
      var buyers=o.available?o.n:f.complete;
      var t=[['Bezoekers',nf(d.visitors)],['Paginaweergaven',nf(d.pageviews)],
        ['Pagina\'s / bezoeker',d.visitors?(d.pageviews/d.visitors).toFixed(1).replace('.',','):'0'],
        ['In winkelwagen',nf(f.cart_add)],['Bestellingen',nf(buyers)]];
      if(o.available){t.push(['Omzet',money(o.revenue)]);t.push(['Gem. orderwaarde',money(o.aov)]);}
      t.push(['Conversie',pct(buyers,d.visitors)]);
      tiles('vt-tiles',t);
      mk('c-daily',{type:'line',data:{labels:days.map(dayLbl),datasets:[
        {label:'Bezoekers',data:days.map(function(k){return d.daily[k].v}),borderColor:C[0],backgroundColor:C[0]+'33',fill:true,tension:.3},
        {label:'Paginaweergaven',data:days.map(function(k){return d.daily[k].p}),borderColor:C[1],tension:.3}]},
        options:Object.assign({},base,{plugins:{legend:{display:true}},scales:{y:{beginAtZero:true}}})});
      mk('c-funnel',{type:'bar',data:{labels:['Product bekeken','In winkelwagen','Checkout','Besteld'],
        datasets:[{data:[f.product,f.cart_add,f.checkout,f.complete],backgroundColor:C.slice(0,4)}]},
        options:Object.assign({},base,{indexAxis:'y',scales:{x:{beginAtZero:true}}})});
      mk('c-hours',{type:'bar',data:{labels:d.hours.map(function(_,i){return i+'u'}),datasets:[{data:d.hours,backgroundColor:C[4]}]},
        options:Object.assign({},base,{scales:{y:{beginAtZero:true}}})});
      hbar('c-products',d.topProducts,C[0]); hbar('c-carted',d.topCarted,C[2]); hbar('c-cats',d.topCats,C[1]);
      hbar('c-search',d.topSearch,C[5]); hbar('c-ref',d.topRef,C[6]);
      if(!d.devices.length){empty('c-dev');}else mk('c-dev',{type:'doughnut',data:{labels:d.devices.map(function(r){return r.n}),datasets:[{data:d.devices.map(function(r){return +r.c}),backgroundColor:C}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right'}}}});
      rowsInto('vt-paths',d.paths.map(function(p){return [p.last_seen,p.country?cname(p.country):'',p.device,p.n,p.path]}),[3]);
    },
    products:function(){
      if(!o.available){byId('vt-noorders').style.display='block';}
      tiles('vt-tiles2',o.available?[['Omzet',money(o.revenue)],['Bestellingen',nf(o.n)],['Verkochte stuks',nf(o.units)],['Gem. orderwaarde',money(o.aov)]]
                                   :[['Bekeken producten',nf(f.product)],['In winkelwagen',nf(f.cart_add)]]);
      if(o.available){
        var od=Object.keys(o.daily);
        mk('c-revday',{type:'bar',data:{labels:od.map(dayLbl),datasets:[{label:'Omzet',data:od.map(function(k){return o.daily[k].r}),backgroundColor:C[1]}]},
          options:Object.assign({},base,{scales:{y:{beginAtZero:true,ticks:{callback:function(v){return money(v)}}}}})});
        var top=d.products.filter(function(p){return p.revenue>0}).slice(0,10);
        hbar('c-toprev',top.map(function(p){return {n:p.name,c:p.revenue}}),C[0],function(v){return money(v)});
      }
      rowsInto('vt-prodtable',d.products.map(function(p){return [p.name,nf(p.views),nf(p.carts),nf(p.units),o.available?money(p.revenue):'-',p.views?(p.units/p.views*100).toFixed(1).replace('.',','):'-']}),[1,2,3,4,5]);
    },
    countries:function(){
      var g=d.geo, c=d.countries;
      var msg='';
      if(g.file){msg='GeoIP-database: '+g.file+' (van '+g.date+'). ';}
      else{msg='Geen GeoIP-database gevonden. Zonder database worden landen alleen bepaald als je shop achter Cloudflare staat. Zie het bestand geoip/README.txt in de pluginmap voor een gratis database.';}
      if(c.unknown&&c.rows.length){msg+=' Bezoekers zonder bekend land: '+nf(c.unknown)+'.';}
      byId('vt-geoinfo').textContent=msg;
      var rows=c.rows.map(function(r){return {n:cname(r.c),c:+r.v}});
      hbar('c-country',rows.slice(0,15),C[0]);
      rowsInto('vt-ctable',c.rows.map(function(r){return [cname(r.c)+' ('+r.c+')',nf(r.v),nf(r.p),nf(r.b)]}),[1,2,3]);
    },
    carts:function(){
      tiles('vt-tiles3',[['Winkelwagens gestart',nf(cr.carts)],['Verlaten',nf(cr.abandoned)],['Percentage verlaten',pct(cr.abandoned,cr.carts)],
        ['Checkout bereikt',nf(cr.checkout)],['Checkout niet afgerond',nf(cr.checkout_abandoned)]]);
      var cd=Object.keys(cr.daily);
      mk('c-cartsday',{type:'bar',data:{labels:cd.map(dayLbl),datasets:[
        {label:'Gestart',data:cd.map(function(k){return cr.daily[k].carts}),backgroundColor:C[0]},
        {label:'Verlaten',data:cd.map(function(k){return cr.daily[k].abandoned}),backgroundColor:C[3]}]},
        options:Object.assign({},base,{plugins:{legend:{display:true}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}})});
      rowsInto('vt-cartprod',cr.products.map(function(p){return [p.name,nf(p.carts),nf(p.abandoned)]}),[1,2]);
      var pd=cr.pending;
      if(pd.available){
        rowsInto('vt-pending',pd.rows.map(function(r){return [r.id,r.date,money(r.total)]}),[2]);
        byId('vt-pendnote').textContent=pd.n?(nf(pd.n)+(pd.n===1?' onbetaalde bestelling':' onbetaalde bestellingen')+', samen '+money(pd.total)+(pd.n>pd.rows.length?' (de nieuwste '+pd.rows.length+' staan hierboven)':'')+'.'):'';
      } else {rowsInto('vt-pending',[]);}
    },
    'export':function(){
      var list=[['dagen','Per dag: bezoekers, weergaven, bestellingen, omzet'],['producten','Alle producten: bekeken, winkelwagen, verkocht, omzet'],
        ['landen','Bezoekers, weergaven en kopers per land'],['winkelwagens','Verlaten winkelwagens per product'],
        ['zoektermen','Zoektermen met aantallen'],['herkomst','Verwijzers met aantal bezoekers'],['events','Alle losse gebeurtenissen (max. 50.000, zonder IP)']];
      var tb=document.querySelector('#vt-exports tbody'); tb.innerHTML='';
      list.forEach(function(x){
        var tr=document.createElement('tr'),a=document.createElement('td'),b=document.createElement('td');
        a.textContent=x[1];
        [['Excel (NL)','nl'],['Standaard','en']].forEach(function(f){
          var l=document.createElement('a');l.className='vt-btn';l.textContent=f[0];
          l.href=BASE+'&days='+d.days+'&export='+x[0]+'&fmt='+f[1];b.appendChild(l);});
        tr.appendChild(a);tr.appendChild(b);tb.appendChild(tr);
      });
    }
  };

  var built={}, nav=byId('nav')||byId('vt-nav');
  function show(id){
    Object.keys(panes).forEach(function(k){byId('vt-p-'+k).style.display=(k===id)?'block':'none';});
    Array.prototype.forEach.call(nav.querySelectorAll('button'),function(b){b.className=(b.getAttribute('data-pane')===id)?'on':'';});
    Array.prototype.forEach.call(root.querySelectorAll('a.vt-period'),function(a){
      var n=a.getAttribute('data-days'); a.href=BASE+'&days='+n+'&pane='+id; a.className='vt-period'+(+n===d.days?' on':'');});
    if(!built[id]){built[id]=true; try{panes[id]();}catch(e){}}
    try{history.replaceState(null,'',location.pathname+BASE+'&days='+d.days+'&pane='+id);}catch(e){}
  }
  Array.prototype.forEach.call(nav.querySelectorAll('button'),function(b){b.addEventListener('click',function(){show(b.getAttribute('data-pane'))});});
  var start=(new URLSearchParams(location.search)).get('pane'); if(!panes[start])start='overview';
  show(start);
  if(d.geo&&d.geo.attribution){byId('vt-attr').textContent=d.geo.attribution;}
})();
{/literal}
</script>
