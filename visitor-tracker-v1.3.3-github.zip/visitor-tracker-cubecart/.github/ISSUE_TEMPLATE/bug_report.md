---
name: Bug report
about: Something does not work as expected
title: ''
labels: bug
---

**CubeCart version:**
**PHP version:**
**SEO-friendly URLs enabled?** yes / no

**What happened?**

**What did you expect?**

**Steps to reproduce**
1.
2.

**Screenshots / error messages / PHP error log lines**

**Checked already**
- [ ] `config.xml` is directly in `modules/plugins/visitor_tracker/` (no nested folder)
- [ ] Hooks `class.cubecart.construct` and `admin.navigation` are enabled in Settings > Manage Hooks
- [ ] I opened the dashboard once after enabling the plugin
- [ ] I cleared the CubeCart cache
